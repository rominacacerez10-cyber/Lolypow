---
name: shorts-lowpoly
description: Hace shorts verticales 3D low poly (estilo PlayStation 1) con Claude Code, sin generador de video con IA. Personajes 3D reales con cara de foto, escenarios con modelos descargados (licencia libre) y utilería en código, movimientos humanos con Kimodo (NVIDIA) o poses a mano, efectos de golpe/grietas/caídas, voz y subtítulos; todo se renderiza con Remotion + three.js. Úsala cuando el usuario pida «un short low poly», «un video estilo PS1», «un short 3D como los de LuisPa», «anima a mi personaje», «hazme un short de [tema] con personajes 3D», o cuando diga «empezar» después de instalar esta skill.
---

# Shorts low poly con Claude Code

Skill gratuita de **Crea con LuisPa** (creaconluispa.com). Es el método con el que se hizo la réplica del short de la pulga: **46 planos en 59 s, corregidos en 11 rondas**. Todo lo que aquí dice «nunca» salió de un error real que ya se cometió y se corrigió; está en `referencias/ERRORES_QUE_NO_SE_REPITEN.md`. **Léelo completo antes de construir el primer plano.**

## Qué hay en esta carpeta
- `proyecto/`: el proyecto de Remotion listo (personaje con esqueleto, gente, ciudad, utilería, trucos de efectos, look PS1) con un short de ejemplo (`Ejemplo`).
- `referencias/`: cómo se hace cada parte. Ábrelas cuando llegues a esa parte; no las cargues todas de golpe.
  - `ERRORES_QUE_NO_SE_REPITEN.md`: obligatorio.
  - `instalacion.md`: herramientas, Kimodo y qué hacer si algo falla.
  - `guion_voz_y_planos.md`: del tema al plan de planos con tiempos.
  - `personajes_y_modelos.md`: protagonista, gente, caras, de dónde bajar modelos y licencias.
  - `movimiento.md`: Kimodo, poses a mano, IK.
  - `trucos_y_efectos.md`: hoyos, techos que se rompen, caídas, golpes y grietas.
  - `revision_y_render.md`: cómo revisar cuadro por cuadro y cómo entregar.
- `proyecto/CREDITOS.md`: autores y licencias de los modelos incluidos. Si el usuario publica, los créditos CC-BY van en la descripción del video.

## Cómo trabajas con el usuario (el orden no se salta)

### 0. Instalación (solo la primera vez)
Sigue `referencias/instalacion.md`. Revisa lo que ya hay en la computadora **antes** de instalar nada, y **pregunta antes de instalar o descargar algo grande** (Kimodo + el modelo de texto pesan ~20 GB). Kimodo es opcional: el ejemplo y las poses a mano funcionan sin él. Al terminar, renderiza el `Ejemplo` y enséñaselo al usuario: así sabe que todo funciona.

### 1. Tema y guion
- Pregunta el tema y, si lo tiene, un short de referencia (de él o de otro creador) para copiar el ritmo.
- Guion de 35–60 s, en el idioma del usuario, una idea por frase. **Ninguna cifra inventada**: si el guion lleva datos (velocidades, precios, récords), búscalos y pon la fuente en un archivo aparte. Si no se puede verificar, se reescribe la frase.
- Enséñale el guion y espera su visto bueno.

### 2. Voz y tiempos
Voz de ElevenLabs (`proyecto/tools/voz_elevenlabs.py`, con su propia llave en la variable `ELEVENLABS_API_KEY`) o la voz del usuario grabada. Saca los tiempos por palabra (AssemblyAI o Whisper). **Nunca pidas ni escribas llaves en el código ni en el chat**: van en variables de entorno.

### 3. Plan de planos
Ver `referencias/guion_voz_y_planos.md`. Un plano por frase o media frase, de **1.2 a 1.8 s** (unos 40–46 planos por minuto). Cada plano **ilustra literalmente** lo que dice la voz: si dice «a 100 km/h», sale un velocímetro en 100. Si hay short de referencia, **mídelo a 30 fps** (cortes, cámara quieta/deriva/movimiento, tamaño del personaje) y cópiale el ritmo. Enséñale al usuario el plan en una tabla: n.º, tiempo, frase, qué se ve, cámara. Espera su visto bueno.

### 4. Personajes, escenarios y movimientos
- **Personajes**: modelos 3D reales con cara de foto (ver `personajes_y_modelos.md`). El protagonista puede llevar la cara del usuario: pídele una foto de frente y haz las 6 expresiones (neutral, feliz, susto, llanto, cansado, serio) con ChatGPT/Codex o con el generador de imágenes que tenga.
- **Escenarios**: modelos descargados con licencia CC0/CC-BY (Poly Haven sin navegador con `tools/polyhaven.py`; Sketchfab con la sesión del usuario), más utilería en código **muy trabajada**. **Nada de cajas.**
- **Movimientos**: clips de Kimodo (`proyecto/public/mov/` ya trae 34) y poses a mano con `ajuste`/IK (ver `movimiento.md`).

### 5. Construir plano por plano
En `proyecto/src/`, un componente por plano dentro de un `Sequence`. Empieza por los 3 planos más difíciles, revísalos (paso 6) y luego sigue. Usa lo que ya existe en `Set.tsx`, `Utileria.tsx`, `Ciudad.tsx`, `Trucos.tsx`, `Beto3D.tsx` y `Modelos.tsx` antes de escribir algo nuevo.

### 6. Revisar cuadro por cuadro (siempre, antes de cada render completo)
Renderiza 6–12 cuadros sueltos con la composición `…Sel`, júntalos en una hoja y **míralos tú** (léelos como imagen). Revisa la lista del final de `ERRORES_QUE_NO_SE_REPITEN.md` en cada cuadro. Si algo sale negro, vacío, deformado, en cajas, lejos o simétrico, corrígelo antes de enseñarlo.

### 7. Sonido y render
Efectos donde algo aparece, cae o pega (cada impacto con su golpe), música baja, voz encima (efectos ~13 dB abajo de la voz, `tools/mezcla_short.py`). Render 1080×1920 a 30 fps. Ver `revision_y_render.md`.

### 8. Correcciones del usuario
El usuario va a mandar capturas con lo que no le gusta. **Anota cada punto y resuélvelos todos en la misma ronda.** Haz los cambios en un archivo nuevo de planos que sobrescriba los anteriores (`Planos2.tsx`, `Planos3.tsx`…) para no romper lo aprobado. Entrega siempre el video completo, no solo el plano que cambió, y si hay referencia, lado a lado (referencia a la izquierda, el suyo a la derecha).

## Reglas que no se negocian
1. **Nada de cajas** ni figuras simples. Si no hay modelo bueno, se hace en código con detalle (texturas, biseles, sombra) o se busca otro modelo.
2. **Que se lea la acción**: si cae, se ve caer y PEGAR, y lo que provoca el golpe (grietas, polvo, pedazos) sale **después** del golpe. Nada se rompe antes de tiempo.
3. **Cerca del personaje.** Si la acción es de él, se ve grande, de cuerpo completo o de la cintura para arriba, con la cara visible.
4. **Cámara casi quieta.** Deriva lenta; sin sacudidas, salvo unos pocos cuadros en un golpe. Una cámara que tiembla todo el tiempo marea y fue el primer error de todos.
5. **Ambientes vivos**: gente cerca haciendo algo, cuadros, relojes con números, plantas, cielo de foto. Nada vacío.
6. **Nada simétrico ni cuadrado** en lo que se rompe: hoyos, grietas y terrones irregulares.
7. **Licencias**: solo CC0 o CC-BY (con crédito). Nada con NC («no comercial»), nada sin licencia. No cambies permisos ni configuración del navegador del usuario; si el navegador frena una descarga, pídele que la permita él.
8. **No publiques nada** por el usuario. Tú entregas el MP4; él decide dónde y cuándo sube.
9. **No inventes**: ni cifras en el guion, ni que algo funcionó si no lo viste en un cuadro renderizado.
