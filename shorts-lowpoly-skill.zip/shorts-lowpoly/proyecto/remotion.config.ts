import {Config} from '@remotion/cli/config';
Config.setVideoImageFormat('jpeg');
Config.setConcurrency(3);
// three.js necesita WebGL en el render sin ventana: «angle» funciona en Mac y Windows (en Linux prueba 'swangle' o 'egl')
Config.setChromiumOpenGlRenderer('angle');
