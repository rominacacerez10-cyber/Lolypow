#!/usr/bin/env python3
"""Mezcla del short: voz + efectos de sonido en sus tiempos -> un WAV listo para unir al video.

Uso: python tools/mezcla_short.py cues.json [salida.wav]
cues.json:
{
  "voz": "public/voz/voz.wav",              (opcional; si no hay voz, solo efectos)
  "duracion": 13.7,                         (segundos del short)
  "carpeta_sfx": "sfx/",                    (dónde están tus efectos; usa solo efectos con licencia que te permita publicarlos)
  "efectos": [
    {"t": 0.0,  "archivo": "whoosh.wav", "db": -16, "dur": 0.6},
    {"t": 8.2,  "archivo": "golpe.wav",  "db": -12, "dur": 1.2}
  ]
}
t = segundo en que entra (para un cuadro: cuadro / 30) · db = ganancia · dur = cuántos segundos del efecto se usan (con fundido de salida).
Los efectos van ~13 dB debajo de la voz y el resultado se normaliza a −14 LUFS (lo normal en redes).
Unir al video: ffmpeg -i out/ejemplo.mp4 -i out/audio_short.wav -c:v copy -c:a aac -b:a 192k -shortest out/final.mp4
"""
import json, os, subprocess, sys

cfg = json.load(open(sys.argv[1]))
OUT = sys.argv[2] if len(sys.argv) > 2 else 'out/audio_short.wav'
SFX = cfg.get('carpeta_sfx', '')
dur = float(cfg.get('duracion', 60))
ins, fl, mix = [], [], []
k = 0
if cfg.get('voz'):
    ins += ['-i', cfg['voz']]; fl.append(f'[{k}:a]volume=1.0[v]'); mix.append('[v]'); k += 1
else:   # sin voz: una pista de silencio de la duración del short para que la mezcla tenga base
    ins += ['-f', 'lavfi', '-t', str(dur), '-i', 'anullsrc=r=44100:cl=stereo']; mix.append(f'[{k}:a]'); k += 1
for e in cfg.get('efectos', []):
    t, d, g = float(e['t']), float(e.get('dur', 1.0)), float(e.get('db', -16))
    ins += ['-i', os.path.join(SFX, e['archivo'])]
    fl.append(f'[{k}:a]atrim=0:{d},afade=t=out:st={max(0, d - 0.12)}:d=0.12,volume={g}dB,adelay={int(t * 1000)}|{int(t * 1000)}[e{k}]'); mix.append(f'[e{k}]'); k += 1
fc = (';'.join(fl) + ';' if fl else '') + ''.join(mix) + f'amix=inputs={len(mix)}:normalize=0:dropout_transition=0,apad=whole_dur={dur},atrim=0:{dur},loudnorm=I=-14:TP=-1.5:LRA=11[o]'
os.makedirs(os.path.dirname(OUT) or '.', exist_ok=True)
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + ins + ['-filter_complex', fc, '-map', '[o]', '-ar', '44100', OUT], check=True)
print('mezcla lista:', OUT, '·', len(cfg.get('efectos', [])), 'efectos')
