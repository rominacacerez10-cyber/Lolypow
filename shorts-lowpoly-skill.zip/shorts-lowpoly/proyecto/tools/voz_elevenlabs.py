#!/usr/bin/env python3
"""Voz con ElevenLabs: una frase por bloque, cada una ajustada (atempo) para caber en su ventana de tiempo,
y todas juntas en una pista del largo del short.

Uso:
  export ELEVENLABS_API_KEY=...        (tu llave; NUNCA la escribas en el código)
  python tools/voz_elevenlabs.py guion.json [carpeta_salida]
guion.json:
{
  "voz_id": "<id de la voz de ElevenLabs>",
  "duracion": 13.7,
  "bloques": [
    {"inicio": 0.2, "fin": 1.4, "texto": "Este es Beto."},
    {"inicio": 1.6, "fin": 3.0, "texto": "Puede caminar..."}
  ]
}
Salida: <carpeta>/voz.wav (−14 LUFS) y los pedazos v_<i>.wav. Requiere ffmpeg.
Si una frase dura más que su ventana se acelera hasta ×1.32 (más rápido ya no se entiende: mejor recorta el texto).
"""
import json, os, ssl, subprocess, sys, urllib.request

key = os.environ.get('ELEVENLABS_API_KEY')
if not key: sys.exit('Falta la variable de entorno ELEVENLABS_API_KEY')
try:
    import certifi; CTX = ssl.create_default_context(cafile=certifi.where())
except ImportError:
    CTX = ssl.create_default_context()
cfg = json.load(open(sys.argv[1]))
D = sys.argv[2] if len(sys.argv) > 2 else 'voz'; os.makedirs(D, exist_ok=True)
BL = cfg['bloques']; DUR = float(cfg.get('duracion', max(b['fin'] for b in BL) + 0.5))
dur_de = lambda f: float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]))
for i, b in enumerate(BL):
    mp3 = os.path.join(D, f'el_{i}.mp3')
    if not (os.path.exists(mp3) and os.path.getsize(mp3) > 1000):   # no se vuelve a pagar una frase que ya existe
        req = urllib.request.Request(f'https://api.elevenlabs.io/v1/text-to-speech/{cfg["voz_id"]}',
                                     data=json.dumps({'text': b['texto'], 'model_id': cfg.get('modelo', 'eleven_multilingual_v2'),
                                                      'voice_settings': {'stability': 0.45, 'similarity_boost': 0.8, 'style': 0.3}}).encode(),
                                     headers={'xi-api-key': key, 'Content-Type': 'application/json', 'Accept': 'audio/mpeg'})
        open(mp3, 'wb').write(urllib.request.urlopen(req, timeout=120, context=CTX).read())
    d = dur_de(mp3); k = max(1.0, min(1.32, d / (b['fin'] - b['inicio'])))
    wav = os.path.join(D, f'v_{i}.wav')
    subprocess.run(['ffmpeg', '-v', 'error', '-y', '-i', mp3, '-af', f'silenceremove=start_periods=1:start_threshold=-45dB,atempo={k:.3f}', '-ar', '44100', '-ac', '2', wav], check=True)
    print(i, f'{d:.1f}s -> x{k:.2f} -> {dur_de(wav):.1f}s (ventana {b["fin"] - b["inicio"]:.1f}s)')
inp, fl = [], []
for i, b in enumerate(BL):
    inp += ['-i', os.path.join(D, f'v_{i}.wav')]; ms = int(b['inicio'] * 1000); fl.append(f'[{i}:a]adelay={ms}|{ms}[a{i}]')
fl.append(''.join(f'[a{i}]' for i in range(len(BL))) + f'amix=inputs={len(BL)}:normalize=0,apad=whole_dur={DUR},atrim=0:{DUR},loudnorm=I=-14:TP=-1.5[voz]')
subprocess.run(['ffmpeg', '-v', 'error', '-y'] + inp + ['-filter_complex', ';'.join(fl), '-map', '[voz]', '-ar', '44100', os.path.join(D, 'voz.wav')], check=True)
print('listo', os.path.join(D, 'voz.wav'))
