#!/usr/bin/env python3
"""Baja un modelo 3D de Poly Haven (CC0: uso libre, también comercial, sin dar crédito) en glTF 1k.

Uso: python tools/polyhaven.py <id> [<id> ...] [--res=1k]
  ej.: python tools/polyhaven.py garden_gnome wooden_hammer_01
  -> public/modelos/ph/<id>/<id>_1k.gltf + .bin + textures/
Los ids salen de la dirección del modelo: https://polyhaven.com/a/<id>   (lista completa: https://api.polyhaven.com/assets?t=models)
Luego agrégalo en src/Modelos.tsx (MODELOS + RUTA) y anótalo en CREDITOS.md.
"""
import json, os, subprocess, sys

# Se baja con `curl` (viene en Mac, Linux y Windows 10+): así no falla por los certificados
# del Python de python.org («CERTIFICATE_VERIFY_FAILED»), que fue lo que nos pasó la primera vez.
API = 'https://api.polyhaven.com/files/'
RES = next((a.split('=', 1)[1] for a in sys.argv if a.startswith('--res=')), '1k')
RAIZ = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'public', 'modelos', 'ph')
UA = 'shorts-lowpoly/1.0'

def curl(url, dst=None):
    args = ['curl', '-sSL', '--fail', '--retry', '3', '-A', UA, url]
    if dst:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        subprocess.run(args + ['-o', dst], check=True)
    else:
        return subprocess.run(args, check=True, capture_output=True).stdout

def bajar(url, dst):
    curl(url, dst)

for id in [a for a in sys.argv[1:] if not a.startswith('--')]:
    info = json.loads(curl(API + id))
    if 'gltf' not in info or RES not in info['gltf']:
        print(f'{id}: no tiene glTF {RES} (¿es una textura o un HDRI?)'); continue
    g = info['gltf'][RES]['gltf']
    dst = os.path.join(RAIZ, id)
    bajar(g['url'], os.path.join(dst, os.path.basename(g['url'])))
    for rel, f in g.get('include', {}).items():   # .bin y texturas, con su ruta relativa
        bajar(f['url'], os.path.join(dst, rel))
    print(f'{id}: listo -> {os.path.relpath(dst)}  ({1 + len(g.get("include", {}))} archivos)')
