#!/usr/bin/env python3
"""Genera los movimientos de tools/prompts_movs.json con Kimodo (NVIDIA) en una sola corrida (el modelo de texto se carga una vez).

Requisitos: el repo de Kimodo instalado (https://github.com/nv-tlabs/kimodo) y el modelo Kimodo-SOMA-RP-v1 en la caché de Hugging Face.
Uso:
  PYTHONPATH=<carpeta del repo de Kimodo> python tools/generar_movs.py [carpeta_salida] [--rehacer] [--solo id1,id2]
  -> <carpeta_salida>/<id>.npz   (por omisión: ./kimodo_salidas/)
Después convierte cada NPZ con tools/exportar_mov.py a public/mov/<id>.json.

prompts_movs.json: {"id": ["descripción del movimiento en inglés", segundos (máx. 10), semilla], ...}
Licencia del modelo: NVIDIA Open Model License (uso comercial permitido; NVIDIA no reclama los movimientos generados).
"""
import os, sys, time, json
import torch  # noqa: F401  (Kimodo lo necesita cargado)
from kimodo.model.load_model import load_model
from kimodo.tools import seed_everything
from kimodo.exports.motion_io import save_kimodo_npz

args = [a for a in sys.argv[1:] if not a.startswith('--')]
OUT = os.path.abspath(args[0] if args else 'kimodo_salidas'); os.makedirs(OUT, exist_ok=True)
PROMPTS = json.load(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'prompts_movs.json')))
SOLO = next((a.split('=', 1)[1].split(',') for a in sys.argv if a.startswith('--solo=')), None)
dev = 'cuda' if torch.cuda.is_available() else 'cpu'   # en Mac va por CPU (~45 s por clip)
model, resolved = load_model('Kimodo-SOMA-RP-v1', device=dev, default_family='Kimodo', return_resolved_name=True)
print('modelo cargado', resolved, 'fps', model.fps, flush=True)
for id, (text, secs, seed) in PROMPTS.items():
    if SOLO and id not in SOLO: continue
    dst = os.path.join(OUT, id + '.npz')
    if os.path.exists(dst) and '--rehacer' not in sys.argv: continue
    t0 = time.time(); seed_everything(seed)
    out = model([text], [int(secs * model.fps)], constraint_lst=[], num_denoising_steps=100, num_samples=1, multi_prompt=True,
                num_transition_frames=5, post_processing=False, return_numpy=True)
    single = {k: (v[0] if hasattr(v, 'shape') and len(v.shape) > 0 and v.shape[0] == 1 else v) for k, v in out.items()}
    save_kimodo_npz(dst, single)
    print('listo', id, round(time.time() - t0, 1), 's', flush=True)
