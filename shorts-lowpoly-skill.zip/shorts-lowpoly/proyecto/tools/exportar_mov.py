#!/usr/bin/env python3
"""NPZ de Kimodo (esqueleto SOMA de 77 articulaciones) -> public/mov/<id>.json con las articulaciones que usa Beto3D.tsx.

Uso: python tools/exportar_mov.py entrada.npz public/mov/<id>.json [--quitar_xz] [--en_sitio]
  --quitar_xz  pone al personaje en el origen al empezar (sigue avanzando si el clip camina)
  --en_sitio   quita el avance de la cadera en cada cuadro (caminar «en una cinta»; tú lo mueves en la escena)
La lista de articulaciones sale del BVH de Kimodo: variable de entorno KIMODO_REPO (carpeta del repo) o --bvh=<ruta>.
"""
import json, os, sys
import numpy as np

bvh = next((a.split('=', 1)[1] for a in sys.argv if a.startswith('--bvh=')), None)
if not bvh:
    repo = os.environ.get('KIMODO_REPO')
    if not repo: sys.exit('Falta KIMODO_REPO=<carpeta del repo de Kimodo> o --bvh=<ruta a somaskel77_standard_tpose.bvh>')
    bvh = os.path.join(repo, 'kimodo', 'assets', 'skeletons', 'somaskel77', 'somaskel77_standard_tpose.bvh')
names = [l.split()[1] for l in open(bvh) if l.strip().startswith(('ROOT', 'JOINT'))]
z = np.load(sys.argv[1]); P = z['posed_joints']; G = z['global_rot_mats']
off = 0 if P.shape[1] == len(names) else 1          # el NPZ trae 77 articulaciones: sin 'Root'
idx = {n: i - off for i, n in enumerate(names) if i - off >= 0}
# mismas articulaciones que los clips incluidos (Beto3D.tsx se probó con exactamente estas)
need = ['Hips', 'Spine2', 'Chest', 'Neck1', 'Head', 'HeadEnd'] + [f'{s}{j}' for s in ('Left', 'Right') for j in
        ('Arm', 'ForeArm', 'Hand', 'HandMiddle1', 'Leg', 'Shin', 'Foot', 'ToeBase', 'ToeEnd')]
if '--quitar_xz' in sys.argv:
    P = P.copy(); c = P[0, idx['Hips'], [0, 2]].copy(); P[:, :, 0] -= c[0]; P[:, :, 2] -= c[1]
if '--en_sitio' in sys.argv:
    P = P.copy(); h = P[:, idx['Hips'], :].copy()
    P[:, :, 0] -= h[:, 0:1]; P[:, :, 2] -= h[:, 2:3]
# apoyar los pies en y = 0
P = P.copy(); P[:, :, 1] -= P[:, [idx['LeftToeBase'], idx['RightToeBase'], idx['LeftFoot'], idx['RightFoot']], 1].min()
out = {'fps': 30, 'n': int(P.shape[0]), 'P': {n: np.round(P[:, idx[n]], 4).tolist() for n in need},
       'R': {n: np.round(G[:, idx[n]].reshape(-1, 9), 4).tolist() for n in ('Hips', 'Spine2', 'Chest', 'Head')}}
json.dump(out, open(sys.argv[2], 'w'))
print('ok', out['n'], 'cuadros; Hips y0 =', round(float(P[0, idx['Hips'], 1]), 3))
