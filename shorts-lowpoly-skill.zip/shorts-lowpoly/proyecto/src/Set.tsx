// El «set»: lienzo three.js de 1080×1920 (Gl), cámara por código (Cam / cam) y piezas sencillas de decorado.
// Cada plano del short es un <Gl> con su cámara, su decorado y sus personajes.
import React, {useMemo} from 'react';
import * as THREE from 'three';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import {lambert} from './ps1';
import {Caja, Cil, Piso, tmat, TEX} from './props';
import {smooth} from './util';
import {Edificio} from './Ciudad';

// activa los planos de recorte (prop `recorte` de Beto3D)
const ClipOn: React.FC = () => { const {gl} = useThree(); React.useLayoutEffect(() => { (gl as any).localClippingEnabled = true; }); return null; };

// Lienzo del plano. stencil:true hace posible el hoyo en el piso (Trucos.tsx).
// px > 1: dibuja a menor resolución y agranda sin suavizar (look pixeleado, p. ej. en un susto).
export const Gl: React.FC<{children: React.ReactNode; bg?: string; fog?: [string, number, number]; px?: number}> = ({children, bg = '#9ec7ea', fog, px = 1}) => (
  <div style={{width: 1080, height: 1920, position: 'relative', background: bg, overflow: 'hidden'}}>
    <ThreeCanvas width={1080} height={1920} dpr={1 / px} gl={{antialias: px <= 1, stencil: true}} camera={{fov: 48, near: 0.05, far: 600, position: [0, 1.5, 4]}} style={{width: 1080, height: 1920, imageRendering: px > 1 ? 'pixelated' : 'auto'}}>
      <color attach="background" args={[bg]} />
      {fog ? <fog attach="fog" args={fog} /> : null}
      <ambientLight intensity={1.2} />
      <directionalLight position={[3, 7, 5]} intensity={1.35} />
      <ClipOn />{children}
    </ThreeCanvas>
  </div>
);

// Cámara fija: posición, punto al que mira, fov y giro (roll, en radianes)
export const Cam: React.FC<{pos: number[]; look: number[]; fov?: number; roll?: number}> = ({pos, look, fov = 45, roll = 0}) => {
  const {camera} = useThree();
  React.useLayoutEffect(() => {
    const c: any = camera;
    c.position.set(pos[0], pos[1], pos[2]); c.fov = fov; c.up.set(Math.sin(roll), Math.cos(roll), 0); c.lookAt(look[0], look[1], look[2]); c.updateProjectionMatrix();
  });
  return null;
};
// Cámara serena: se desliza poquito de p0 a p1 durante el plano (n cuadros). Así la cámara nunca está congelada.
export const cam = (f: number, n: number, p0: number[], p1: number[], look: number[], fov = 45, push = 1) => {
  const t = smooth(f / Math.max(1, n)) * push; const L = (i: number) => p0[i] + (p1[i] - p0[i]) * t;
  return <Cam pos={[L(0), L(1), L(2)]} look={look} fov={fov} />;
};

// Plano con textura o color, mirando a +z (rótalo con r para paredes o pisos). basic = sin luz (colores de la foto tal cual).
export const Pl: React.FC<{p: [number, number, number]; w: number; h: number; t?: string; ts?: number; c?: string; r?: [number, number, number]; tint?: string; basic?: boolean}> = ({p, w, h, t, ts = 1.5, c = '#888', r = [0, 0, 0], tint, basic}) => {
  const m = useMemo(() => {
    if (t && basic && TEX[t]) { const tx = TEX[t].clone(); tx.wrapS = tx.wrapT = THREE.MirroredRepeatWrapping; tx.repeat.set(w / ts, h / ts); tx.needsUpdate = true; return new THREE.MeshBasicMaterial({map: tx, ...(tint ? {color: tint} : {})}); }
    return t ? tmat(t, w / ts, h / ts, tint) : basic ? new THREE.MeshBasicMaterial({color: c}) : lambert(c);
  }, [t, w, h, ts, c, tint, basic]);
  return <mesh position={p} rotation={r} material={m}><planeGeometry args={[w, h]} /></mesh>;
};
export const Esf: React.FC<{p: [number, number, number]; r: number; c: string; s?: [number, number, number]; basic?: boolean}> = ({p, r, c, s = [1, 1, 1], basic}) => {
  const m = useMemo(() => (basic ? new THREE.MeshBasicMaterial({color: c}) : lambert(c)), [c, basic]);
  return <mesh position={p} scale={s} material={m}><sphereGeometry args={[r, 20, 14]} /></mesh>;
};
// Segmento (cilindro) entre dos puntos
export const Seg: React.FC<{a: number[]; b: number[]; r: number; c: string; r2?: number}> = ({a, b, r, c, r2}) => {
  const d = new THREE.Vector3(b[0] - a[0], b[1] - a[1], b[2] - a[2]); const L = d.length() || 1e-4;
  const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize());
  const m = useMemo(() => lambert(c), [c]);
  return <mesh position={[(a[0] + b[0]) / 2, (a[1] + b[1]) / 2, (a[2] + b[2]) / 2]} quaternion={q} material={m}><cylinderGeometry args={[r2 ?? r, r, L, 10]} /></mesh>;
};

// ---------- cielo pintado (textura «cielo» o «cielo_nubes») ----------
export const Cielo: React.FC<{z?: number; y?: number; t?: string}> = ({z = -90, y = 40, t = 'cielo'}) => <Pl p={[0, y, z]} w={z * -3.4} h={z * -2.2} t={t} ts={z * -2.2} basic />;

// ---------- sala (papel tapiz, parquet, cuadro, lámpara) ----------
export const Mesita: React.FC<{p: [number, number, number]}> = ({p}) => (
  <group position={p}><Caja s={[0.9, 0.06, 0.6]} c="#c9a56b" p={[0, 0.4, 0]} />{[[-0.4, -0.25], [0.4, -0.25], [-0.4, 0.25], [0.4, 0.25]].map(([x, z], i) => <Caja key={i} s={[0.05, 0.4, 0.05]} c="#a37c44" p={[x, 0.2, z]} />)}</group>
);
export const Cuadro: React.FC<{p: [number, number, number]; w?: number; h?: number}> = ({p, w = 0.55, h = 0.42}) => (
  <group position={p}><Caja s={[w + 0.1, h + 0.1, 0.04]} c="#7b5a2a" /><Pl p={[0, 0, 0.025]} w={w} h={h} t="cielo" ts={1.2} tint="#a98a5a" basic /></group>
);
export const Lampara: React.FC<{p: [number, number, number]}> = ({p}) => (
  <group position={p}><Caja s={[0.02, 1.2, 0.02]} c="#ddd" p={[0, 0.6, 0]} /><Esf p={[0, 0, 0]} r={0.28} c="#f5f5f0" basic /></group>
);
// pared con papel tapiz de piso a ~2.8 m, zoclo y piso; z = pared del fondo
export const Sala: React.FC<{tapiz?: string; z?: number; ancho?: number; piso?: string; sinPiso?: boolean}> = ({tapiz = 'tapiz_durazno', z = -5, ancho = 16, piso = 'parquet', sinPiso = false}) => (
  <>
    <Pl p={[0, 1.4, z]} w={ancho} h={2.8} t={tapiz} ts={1.7} basic />
    <Pl p={[0, 6.0, z + 0.01]} w={ancho} h={6.4} c="#a2a09c" basic />
    <Caja s={[ancho, 0.15, 0.06]} c="#8b5a2b" p={[0, 0.07, z + 0.03]} />
    {!sinPiso && <Piso w={ancho} d={18} t={piso} ts={1.5} p={[0, 0, z + 9]} />}
  </>
);

// ---------- escalera de bloques con pasamanos ----------
export const Escalera: React.FC<{p: [number, number, number]; pasos?: number}> = ({p, pasos = 9}) => (
  <group position={p}>
    {Array.from({length: pasos}).map((_, i) => <Caja key={i} s={[0.7, 0.22 * (i + 1), 0.9]} t="parquet" ts={0.8} p={[i * 0.33, 0.11 * (i + 1), 0]} />)}
    <Seg a={[0, 1.0, 0.42]} b={[pasos * 0.33, 0.22 * pasos + 1.0, 0.42]} r={0.04} c="#6b3f1f" />
  </group>
);

// ---------- calle ----------
// Edificio por centro y tamaño (usa la fachada de canvas de Ciudad.tsx). tono: 'beige' | 'cafe' | 'blanco'
export const Edif: React.FC<{p: [number, number, number]; s: [number, number, number]; tono?: 'beige' | 'cafe' | 'blanco'}> = ({p, s, tono = 'beige'}) => (
  <Edificio p={[p[0], p[1] - s[1] / 2, p[2]]} w={s[0]} h={s[1]} d={s[2]} pisos={Math.max(3, Math.round(s[1] / 2.9))} cols={Math.max(3, Math.round(s[0] / 1.3))} tono={tono} seed={Math.round(p[0] * 7 + p[2] * 3) + 50} />
);
export const Bote: React.FC<{p: [number, number, number]}> = ({p}) => <Cil p={[p[0], p[1] + 0.45, p[2]]} r={0.35} h={0.9} c="#2f8f4a" seg={12} />;
export const Hidrante: React.FC<{p: [number, number, number]}> = ({p}) => <Cil p={[p[0], p[1] + 0.35, p[2]]} r={0.18} h={0.7} c="#d2321f" seg={10} />;

// ---------- escombro (cubitos que saltan una vez, con sube > 0) ----------
const rnd = (i: number, k = 1) => { const x = Math.sin(i * 12.9898 * k + 78.233) * 43758.5453; return x - Math.floor(x); };
export const Escombro: React.FC<{n: number; r: number; c?: string; c2?: string; y?: number; tam?: number; centro?: [number, number]; sube?: number; f?: number}> = ({n, r, c = '#c9b79a', c2 = '#ddd2bd', y = 0.1, tam = 0.22, centro = [0, 0], sube = 0, f = 0}) => (
  <>{Array.from({length: n}).map((_, i) => {
    const a = rnd(i) * Math.PI * 2, d = r * (0.35 + rnd(i, 2) * 0.8), s = tam * (0.5 + rnd(i, 3));
    return <Caja key={i} s={[s, s * 0.8, s]} c={rnd(i, 4) > 0.5 ? c : c2} p={[centro[0] + Math.cos(a) * d, y + sube * Math.sin(Math.min(1, f / 16) * Math.PI) * (0.4 + rnd(i, 5)), centro[1] + Math.sin(a) * d]} r={[rnd(i, 6) * 3, rnd(i, 7) * 3, rnd(i, 8) * 3]} />;
  })}</>
);

// ---------- resplandor (degradado radial aditivo) ----------
export const Brillo: React.FC<{p: [number, number, number]; w: number; h: number; c?: string}> = ({p, w, h, c = '#7dffd0'}) => {
  const m = useMemo(() => {
    const cv = document.createElement('canvas'); cv.width = cv.height = 128; const g = cv.getContext('2d')!;
    const gr = g.createRadialGradient(64, 64, 4, 64, 64, 64); gr.addColorStop(0, c + 'ee'); gr.addColorStop(0.45, c + '66'); gr.addColorStop(1, c + '00'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
    return new THREE.MeshBasicMaterial({map: new THREE.CanvasTexture(cv), transparent: true, blending: THREE.AdditiveBlending, depthWrite: false});
  }, [c]);
  return <mesh position={p} material={m}><planeGeometry args={[w, h]} /></mesh>;
};

// ---------- imagen recortada (PNG con transparencia) como cartel en la escena ----------
export const Img: React.FC<{t: string; p: [number, number, number]; w: number; h: number; op?: number; cutout?: boolean}> = ({t, p, w, h, op = 1, cutout}) => {
  const m = useMemo(() => new THREE.MeshBasicMaterial({map: TEX[t], transparent: !!cutout, depthWrite: !cutout}), [t]);
  m.opacity = op; m.transparent = !!cutout || op < 1;
  if (!TEX[t]) return null;
  return <mesh position={p} material={m} renderOrder={cutout ? 5 : 0}><planeGeometry args={[w, h]} /></mesh>;
};
