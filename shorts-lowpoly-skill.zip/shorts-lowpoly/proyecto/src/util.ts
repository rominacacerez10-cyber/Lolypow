export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const smooth = (t: number) => { t = clamp(t); return t * t * t * (t * (t * 6 - 15) + 10); };
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
// Interpolación por llaves [[cuadro, valor], ...] con smootherstep
export const kf = (f: number, k: number[][]): number => {
  if (f <= k[0][0]) return k[0][1];
  for (let i = 1; i < k.length; i++) if (f <= k[i][0]) return lerp(k[i - 1][1], k[i][1], smooth((f - k[i - 1][0]) / (k[i][0] - k[i - 1][0])));
  return k[k.length - 1][1];
};
export const kf3 = (f: number, k: [number, number[]][]): [number, number, number] =>
  [0, 1, 2].map(i => kf(f, k.map(([t, v]) => [t, v[i]]))) as [number, number, number];
// Deriva siempre viva (la cámara nunca se queda quieta)
export const drift = (f: number, a = 0.03): [number, number, number] => [Math.sin(f * 0.045) * a, Math.cos(f * 0.037) * a * 0.7, Math.sin(f * 0.029 + 1) * a];
