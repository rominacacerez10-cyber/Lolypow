// PERSONAJES 3D con esqueleto.
// - Personaje base: «PSX Male Character» de 32Dev3 (itch.io, CC0): 919 vértices, esqueleto Rigify, textura de 256×256.
//   La ropa se recolorea en un canvas y la cara se cambia por una foto (public/caras/<cara>.png) → prop `carita`.
// - Gente: paquete de Elbolillo (CC-BY) riggeado en código con el mismo esqueleto → prop `persona`.
// - Movimiento: clips de Kimodo (public/mov/<id>.json) retargeteados por dirección de hueso + giro del torso/cabeza.
// - Pose a mano después del clip: prop `ajuste(rig)` (gira huesos, IK con ikBrazo / ik2). Objetos pegados a un hueso: prop `extra(rig)`.
// Nombres de hueso (three.js les quita los puntos): DEF-spine … DEF-spine006 (cabeza), DEF-upper_armL/R, DEF-forearmL/R, DEF-handL/R,
// DEF-thighL/R, DEF-shinL/R, DEF-footL/R, DEF-toeL/R.
import React from 'react';
import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {clone as skClone} from 'three/examples/jsm/utils/SkeletonUtils.js';
import {staticFile, delayRender, continueRender} from 'remotion';
import {snap, nearest} from './ps1';
import {TEX} from './props';
import {CARAS, VARIANTES, Cara} from './caras';

// Clip de movimiento (salida de tools/exportar_mov.py): posiciones P y rotaciones R por articulación y por cuadro, a 30 fps
export type Mov = {fps: number; n: number; P: Record<string, number[][]>; R: Record<string, number[][]>};
export type Persona = {geom: THREE.BufferGeometry; map: THREE.Texture; alto: number; armDir?: {pos: number[]; neg: number[]}};
export type Modelo = {scene: THREE.Group; tex: Record<string, THREE.CanvasTexture>; pers?: Record<string, Persona>};
const RECT = [16, 4, 88, 120];           // rectángulo de la cara frontal en la textura de 256×256 del personaje base

const img = (src: string) => new Promise<HTMLImageElement>((res, rej) => { const i = new Image(); i.onload = () => res(i); i.onerror = rej; i.src = src; });

// Recolorea la textura del personaje base (sudadera → camisa, jeans → pantalón, tenis → zapatos negros, piel y cabello) y pega la cara.
type Ropa = {camisa: (L: number) => number[]; pant: (L: number) => number[]};
const ROJO: Ropa = {camisa: L => [70 + L * 330, 12 + L * 50, 14 + L * 46], pant: L => { const v = 12 + L * 55; return [v, v, v + 3]; }};
export const ROPAS: Record<string, Ropa> = {
  rojo: ROJO,
  verde: {camisa: L => [20 + L * 150, 100 + L * 280, 35 + L * 120], pant: L => [120 + L * 300, 100 + L * 260, 62 + L * 150]},
  bata: {camisa: L => [160 + L * 260, 160 + L * 260, 165 + L * 260], pant: L => [28 + L * 70, 50 + L * 100, 90 + L * 180]},
  piloto: {camisa: L => [125 + L * 280, 110 + L * 240, 80 + L * 170], pant: L => [45 + L * 120, 48 + L * 120, 28 + L * 80]},
  azul: {camisa: L => [30 + L * 120, 70 + L * 220, 130 + L * 300], pant: L => [150 + L * 250, 130 + L * 220, 110 + L * 200]},
};

const componer = (base: HTMLImageElement, cara: HTMLImageElement | null, piel: [number, number, number], ropa: Ropa = ROJO) => {
  const c = document.createElement('canvas'); c.width = c.height = 256; const g = c.getContext('2d', {willReadFrequently: true})!;
  g.drawImage(base, 0, 0, 256, 256);
  const d = g.getImageData(0, 0, 256, 256); const p = d.data;
  const inR = (x: number, y: number, a: number, b: number, c2: number, e: number) => x >= a && x < c2 && y >= b && y < e;
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const i = (y * 256 + x) * 4; const r = p[i], gr = p[i + 1], b = p[i + 2];
    const L = (r * 0.3 + gr * 0.59 + b * 0.11) / 255; if (r + gr + b < 12) continue;
    if (inR(x, y, 0, 163, 122, 242)) { const q = ropa.camisa(L); p[i] = Math.min(255, q[0]); p[i + 1] = Math.min(255, q[1]); p[i + 2] = Math.min(255, q[2]); }          // sudadera → camisa
    else if (inR(x, y, 176, 163, 228, 256)) { const q = ropa.pant(L); p[i] = Math.min(255, q[0]); p[i + 1] = Math.min(255, q[1]); p[i + 2] = Math.min(255, q[2]); }                     // jeans → pantalón
    else if (inR(x, y, 172, 94, 205, 152)) { const v = 10 + L * 45; p[i] = v; p[i + 1] = v; p[i + 2] = v; }                         // tenis → zapatos negros
    else if (inR(x, y, 126, 163, 152, 256)) { const v = 12 + L * 40; p[i] = v; p[i + 1] = v; p[i + 2] = v; }                         // calcetines
    else {
      // cabello/barba oscura → negro; piel → el tono pedido
      const hairA = inR(x, y, 128, 22, 212, 92) || inR(x, y, 90, 100, 166, 166);
      if (hairA && L < 0.55) { const v = 8 + L * 55; p[i] = v; p[i + 1] = v * 0.92; p[i + 2] = v * 0.88; }
      else if (L < 0.3 && inR(x, y, 0, 0, 126, 125)) { const v = 10 + L * 60; p[i] = v; p[i + 1] = v * 0.9; p[i + 2] = v * 0.85; }
      else if (inR(x, y, 0, 0, 128, 125) || inR(x, y, 0, 112, 56, 146) || inR(x, y, 218, 0, 256, 156)) {
        const k = L / 0.72; p[i] = Math.min(255, piel[0] * k); p[i + 1] = Math.min(255, piel[1] * k); p[i + 2] = Math.min(255, piel[2] * k);
      }
    }
  }
  g.putImageData(d, 0, 0);
  const big = document.createElement('canvas'); big.width = big.height = 1024; const bg = big.getContext('2d')!;
  bg.imageSmoothingEnabled = true; bg.imageSmoothingQuality = 'high'; bg.drawImage(c, 0, 0, 1024, 1024);
  if (cara) bg.drawImage(cara, RECT[0] * 4, RECT[1] * 4, (RECT[2] - RECT[0]) * 4, (RECT[3] - RECT[1]) * 4);
  const t = new THREE.CanvasTexture(big); t.flipY = false; t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; t.colorSpace = THREE.SRGBColorSpace; return t;
};

// GENTE: paquete «Characters_ Extras» de Elbolillo (CC-BY, 28 personas con cara de foto, mallas SIN esqueleto).
// Se riggean aquí, en código, con el esqueleto del personaje base: cada vértice toma peso de los huesos más cercanos
// (distancia a los segmentos de hueso), separando islas de malla por familia (brazos / piernas / columna) para que no salgan «alas».
const cargarPersonas = async (base: THREE.Group): Promise<Record<string, Persona>> => {
  const gltf: any = await new Promise((res, rej) => new GLTFLoader().load(staticFile('modelos/elbolillo/scene.gltf'), res, undefined, rej));
  gltf.scene.updateMatrixWorld(true);
  let bm: THREE.SkinnedMesh | null = null; base.traverse((o: any) => { if (o.isSkinnedMesh) bm = o; });
  const bg = bm!.geometry as THREE.BufferGeometry; const bp = bg.attributes.position as THREE.BufferAttribute; const bi = bg.attributes.skinIndex, bw = bg.attributes.skinWeight;
  base.updateMatrixWorld(true); const bones = bm!.skeleton.bones; const inv = new THREE.Matrix4().copy(bm!.matrixWorld).invert();
  const wp = bones.map(b => b.getWorldPosition(new THREE.Vector3()).applyMatrix4(inv));
  const SEG: {idx: number; a: number[]; b: number[]}[] = [];
  bones.forEach((b, idx) => {
    const hijos = b.children.filter((c: any) => c.isBone).map((c: any) => bones.indexOf(c)).filter(k => k >= 0);
    let tail: THREE.Vector3;
    if (hijos.length) { tail = hijos.reduce((v, k) => v.add(wp[k]), new THREE.Vector3()).multiplyScalar(1 / hijos.length); }
    else { const par = bones.indexOf(b.parent as any); tail = par >= 0 ? wp[idx].clone().add(wp[idx].clone().sub(wp[par]).multiplyScalar(0.8)) : wp[idx].clone().add(new THREE.Vector3(0, 0.1, 0)); }
    SEG.push({idx, a: [wp[idx].x, wp[idx].y, wp[idx].z], b: [tail.x, tail.y, tail.z]});
  });
  const PELVIS = Math.max(0, bones.findIndex(b => b.name === 'DEF-spine'));
  const brazo = (b: THREE.Bone) => { const m = b.name.match(/^DEF-(upper_arm|forearm|hand)([LR])(001)?$/); return m ? {tipo: m[1], lado: m[2], twist: !!m[3]} : null; };
  const out: Record<string, Persona> = {};
  gltf.scene.traverse((o: any) => {
    if (!o.isMesh) return;
    const nombre = ((o.name as string).match(/^.*?_(Character_.+?)_0(\.\d+)?$/) ?? [])[1] ?? (o.name as string); const mat = Array.isArray(o.material) ? o.material[0] : o.material; if (!mat.map) return;
    const g = o.geometry.clone().applyMatrix4(o.matrixWorld); g.computeBoundingBox(); const b = g.boundingBox!;
    const sz = b.getSize(new THREE.Vector3()); if (sz.y > 2.6 || sz.y < 0.8) return;      // solo humanos de tamaño normal
    const k = 1.81 / sz.y; const cx = (b.min.x + b.max.x) / 2, cz = (b.min.z + b.max.z) / 2;
    const pos = g.attributes.position as THREE.BufferAttribute; const n = pos.count;
    // normaliza al espacio del personaje base (alto 1.81, pies en y=0) probando 4 giros para ver hacia dónde mira
    const probar = (ang: number) => {
      const c = Math.cos(ang), s2 = Math.sin(ang); const P = new Float32Array(n * 3); let d = 0;
      for (let i = 0; i < n; i++) { const x = (pos.getX(i) - cx) * k, y = (pos.getY(i) - b.min.y) * k, z = (pos.getZ(i) - cz) * k; P[i * 3] = x * c + z * s2; P[i * 3 + 1] = y; P[i * 3 + 2] = -x * s2 + z * c; }
      for (let i = 0; i < n; i += 6) { let m = 1e9; for (let j = 0; j < bp.count; j += 2) { const dx = P[i * 3] - bp.getX(j), dy = P[i * 3 + 1] - bp.getY(j), dz = P[i * 3 + 2] - bp.getZ(j); const q = dx * dx + dy * dy + dz * dz; if (q < m) m = q; } d += m; }
      return {P, d};
    };
    let mejor = probar(0); for (let a = 1; a < 4; a++) { const r = probar(a * Math.PI / 2); if (r.d < mejor.d) mejor = r; }
    const P = mejor.P; for (let i = 0; i < n; i++) { P[i * 3] = -P[i * 3]; P[i * 3 + 2] = -P[i * 3 + 2]; }   // mira a +z
    // los brazos de este personaje salen más abiertos que los del personaje base: se reubican los segmentos de brazo del esqueleto hacia la punta de su mano
    const punta: Record<string, number[]> = {}; for (const lado of ['L', 'R']) { const sg = lado === 'L' ? 1 : -1; let bi2 = -1, bx = -1e9; for (let i = 0; i < n; i++) { const v = P[i * 3] * sg; if (v > bx && P[i * 3 + 1] > 0.5) { bx = v; bi2 = i; } } punta[lado] = [P[bi2 * 3], P[bi2 * 3 + 1], P[bi2 * 3 + 2]]; }
    const esBrazo = new Uint8Array(n);
    // pre-pose: el brazo de la malla (A-pose, abierto) se gira hacia abajo, a la posición de reposo del esqueleto base, antes de calcular los pesos
    for (const lado of ['L', 'R']) {
      const hb = bones.find(q => q.name === `DEF-upper_arm${lado}`)!, mb = bones.find(q => q.name === `DEF-handL`.replace('L', lado))!; const h0 = wp[bones.indexOf(hb)], h1 = wp[bones.indexOf(mb)];
      const tip = punta[h0.x >= 0 ? 'L' : 'R']; const dirM = new THREE.Vector3(tip[0] - h0.x, tip[1] - h0.y, tip[2] - h0.z); const Lm = dirM.length(); dirM.normalize();
      const dirT = new THREE.Vector3(h1.x - h0.x, h1.y - h0.y, h1.z - h0.z).normalize();
      const qq = new THREE.Quaternion().setFromUnitVectors(dirM, dirT); const idq = new THREE.Quaternion();
      const sg = h0.x >= 0 ? 1 : -1;
      for (let i = 0; i < n; i++) {
        if (P[i * 3] * sg < 0.1) continue;
        const v = new THREE.Vector3(P[i * 3] - h0.x, P[i * 3 + 1] - h0.y, P[i * 3 + 2] - h0.z); const t = v.dot(dirM) / Lm; if (t < 0 || t > 1.15) continue;
        const dperp = v.clone().addScaledVector(dirM, -v.dot(dirM)).length(); if (dperp > 0.13) continue;
        if (t > 0.18) esBrazo[i] = 1;
        const w = Math.min(1, Math.max(0, (t - 0.02) / 0.28)); const q2 = idq.clone().slerp(qq, w); v.applyQuaternion(q2);
        P[i * 3] = h0.x + v.x; P[i * 3 + 1] = h0.y + v.y; P[i * 3 + 2] = h0.z + v.z;
      }
    }
    const SEGp = SEG.map(sg0 => ({...sg0}));
    const si = new Uint16Array(n * 4), sw = new Float32Array(n * 4);
    // 1) islas de la malla (brazo, pierna, torso…) por conectividad de triángulos; cada isla se limita a una «familia» de huesos (brazos / piernas / columna)
    const fam = (j: number) => (/shoulder|upper_arm|forearm|hand|f_/.test(bones[j].name) ? 'brazo' : /pelvis|thigh|shin|foot|toe/.test(bones[j].name) ? 'pierna' : 'columna');
    const padre = new Int32Array(n).map((_, i) => i); const raiz = (i: number): number => { while (padre[i] !== i) { padre[i] = padre[padre[i]]; i = padre[i]; } return i; };
    const idx = g.index!; for (let t = 0; t < idx.count; t += 3) { const a0 = raiz(idx.getX(t)), b0 = raiz(idx.getX(t + 1)), c0 = raiz(idx.getX(t + 2)); padre[b0] = a0; padre[raiz(c0)] = a0; }
    const dist = (i: number, j: number) => { const sg = SEGp[j]; const x = P[i * 3], y = P[i * 3 + 1], z = P[i * 3 + 2]; const vx = sg.b[0] - sg.a[0], vy = sg.b[1] - sg.a[1], vz = sg.b[2] - sg.a[2]; const L2 = vx * vx + vy * vy + vz * vz || 1e-6; const t = Math.max(0, Math.min(1, ((x - sg.a[0]) * vx + (y - sg.a[1]) * vy + (z - sg.a[2]) * vz) / L2)); const dx = x - (sg.a[0] + vx * t), dy = y - (sg.a[1] + vy * t), dz = z - (sg.a[2] + vz * t); return Math.sqrt(dx * dx + dy * dy + dz * dz); };
    const votos: Record<number, Record<string, number>> = {};
    for (let i = 0; i < n; i++) { if (esBrazo[i]) continue; let m = 1e9, mj = 0; for (let j = 0; j < SEGp.length; j++) { const d = dist(i, j); if (d < m) { m = d; mj = j; } } const r = raiz(i); (votos[r] ??= {}); const f0 = fam(SEGp[mj].idx); votos[r][f0] = (votos[r][f0] ?? 0) + 1; }
    const famDe: Record<number, string> = {}; for (const r of Object.keys(votos)) famDe[+r] = Object.entries(votos[+r]).sort((x, y) => y[1] - x[1])[0][0];
    for (let i = 0; i < n; i++) {
      const fm = esBrazo[i] ? 'brazo' : famDe[raiz(i)]; const ds: {j: number; d: number}[] = [];
      for (let j = 0; j < SEGp.length; j++) { const fj = fam(SEGp[j].idx); if (fm !== 'pierna' && fj === 'brazo' && !esBrazo[i] && P[i * 3 + 1] < 1.32 && Math.abs(P[i * 3]) < 0.3) continue; if (fm === 'pierna' ? !(fj === 'pierna' || /spine$/.test(bones[SEGp[j].idx].name)) : fj === 'pierna') continue; ds.push({j: SEGp[j].idx, d: dist(i, j)}); }
      ds.sort((p1, p2) => p1.d - p2.d); const nearArm = P[i * 3 + 1] > 1.25 && Math.abs(P[i * 3]) < 0.42; const kx = Math.min(1, Math.max(0.6, (Math.abs(P[i * 3]) - 0.06) / 0.1)); const top = ds.slice(0, 4).map(e => ({j: e.j, w: (e.d < ds[0].d * (nearArm ? 2.6 : 1.6) + 0.01 ? 1 / (Math.pow(e.d, nearArm ? 1.0 : 2.0) + 1e-3) : 0) * (fm !== 'pierna' && /upper_arm|forearm|hand|f_/.test(bones[e.j].name) ? kx : 1)}));
      const tot = top.reduce((q, e) => q + e.w, 0) || 1;
      top.forEach((e, t) => { si[i * 4 + t] = e.j; sw[i * 4 + t] = e.w / tot; });
    }
    const ng = new THREE.BufferGeometry(); ng.setAttribute('position', new THREE.BufferAttribute(P, 3)); ng.setAttribute('uv', g.attributes.uv); if (g.attributes.normal) ng.setAttribute('normal', g.attributes.normal);
    ng.setAttribute('skinIndex', new THREE.BufferAttribute(si, 4)); ng.setAttribute('skinWeight', new THREE.BufferAttribute(sw, 4)); ng.setIndex(g.index);
    const tx = mat.map as THREE.Texture; tx.colorSpace = THREE.SRGBColorSpace; tx.anisotropy = 8; tx.magFilter = THREE.LinearFilter;
    const dirB = (tip: number[], h0: THREE.Vector3) => { const v = new THREE.Vector3(tip[0] - h0.x, tip[1] - h0.y, tip[2] - h0.z).normalize(); return [v.x, v.y, v.z]; };
    const hp = bones.find(q => /^DEF-upper_armL$/.test(q.name)); const hpos = wp[bones.indexOf(hp!)]; const lSign = hpos.x >= 0 ? 'L' : 'R'; const rSign = lSign === 'L' ? 'R' : 'L';
    const hneg = new THREE.Vector3(-hpos.x, hpos.y, hpos.z);
    out[nombre] = {geom: ng, map: tx, alto: sz.y, armDir: {pos: dirB(punta[lSign], hpos), neg: dirB(punta[rSign], hneg)}};
  });
  // variante «Rojo»: Character_Male_36 (camisa blanca) con la camisa teñida de rojo
  const base0 = out['Character_Male_36'];
  if (base0) {
    const im: any = base0.map.image; const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const g = c.getContext('2d', {willReadFrequently: true})!; g.drawImage(im, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height); const p = d.data;
    for (let i = 0; i < p.length; i += 4) { const mx = Math.max(p[i], p[i + 1], p[i + 2]), mn = Math.min(p[i], p[i + 1], p[i + 2]); if (mn > 140 && mx - mn < 45) { const L = (p[i] + p[i + 1] + p[i + 2]) / 765; p[i] = Math.min(255, 70 + L * 215); p[i + 1] = 10 + L * 40; p[i + 2] = 12 + L * 38; } }
    g.putImageData(d, 0, 0); const t = new THREE.CanvasTexture(c); t.flipY = base0.map.flipY; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
    out['Rojo'] = {geom: base0.geom, map: t, alto: base0.alto};
  }
  // variante «Doctor»: Character_Male_37 con la chamarra gris convertida en bata blanca y el pantalón en mezclilla (la cara no se toca)
  const b37 = out['Character_Male_37'];
  if (b37) {
    const im: any = b37.map.image; const W = im.width, H = im.height; const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d', {willReadFrequently: true})!; g.drawImage(im, 0, 0);
    const d = g.getImageData(0, 0, W, H); const p = d.data;
    const cara = (x: number, y: number) => (x > 0.28 * W && x < 0.49 * W && y > 0.66 * H && y < 0.86 * H) || (x > 0.68 * W && x < 0.9 * W && y > 0.68 * H && y < 0.86 * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4; const r = p[i], gg = p[i + 1], b = p[i + 2]; const mx = Math.max(r, gg, b), mn = Math.min(r, gg, b); const L = (r + gg + b) / 765;
      if (cara(x, y) || mx - mn > 28 || mx < 8) continue;                        // piel, zapatos cafés, cara y fondo negro se quedan
      const pant = (x < 0.5 * W && y < 0.42 * H && x < 0.25 * W) || (x < 0.22 * W && y >= 0.42 * H && y < 0.82 * H) || (x > 0.72 * W && x < 0.86 * W && y > 0.38 * H && y < 0.62 * H);
      const camisa = L > 0.3;
      if (pant && L < 0.2) { p[i] = 40 + L * 160; p[i + 1] = 62 + L * 220; p[i + 2] = 105 + L * 330; }
      else if (!camisa && L < 0.3) { const v = 205 + L * 160; p[i] = Math.min(255, v); p[i + 1] = Math.min(255, v); p[i + 2] = Math.min(255, v + 4); }
      else if (camisa) { const v = 30 + L * 50; p[i] = v; p[i + 1] = v; p[i + 2] = v + 6; }
    }
    g.putImageData(d, 0, 0); const t = new THREE.CanvasTexture(c); t.flipY = b37.map.flipY; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
    out['Doctor'] = {...b37, map: t};
  }
  // variante «Piloto»: Character_Male_38 (camisa azul marino) con camisa caqui y pantalón verde olivo
  const b38 = out['Character_Male_38'];
  if (b38) {
    const im: any = b38.map.image; const W = im.width, H = im.height; const c = document.createElement('canvas'); c.width = W; c.height = H; const g = c.getContext('2d', {willReadFrequently: true})!; g.drawImage(im, 0, 0);
    const d = g.getImageData(0, 0, W, H); const p = d.data;
    const cara = (x: number, y: number) => (x > 0.28 * W && x < 0.49 * W && y > 0.66 * H && y < 0.86 * H) || (x > 0.68 * W && x < 0.9 * W && y > 0.68 * H && y < 0.86 * H);
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4; const r = p[i], gg = p[i + 1], b = p[i + 2]; const L = (r + gg + b) / 765;
      if (cara(x, y) || Math.max(r, gg, b) < 8) continue;
      if (b > r + 12 && b >= gg) { const v = 0.95 + L * 1.8; p[i] = Math.min(255, 158 * v); p[i + 1] = Math.min(255, 140 * v); p[i + 2] = Math.min(255, 98 * v); }       // camisa → caqui
      else if (L < 0.2 && Math.max(r, gg, b) - Math.min(r, gg, b) < 25) { const v = 0.7 + L * 2.5; p[i] = 52 * v; p[i + 1] = 58 * v; p[i + 2] = 38 * v; }   // pantalón → verde olivo
    }
    g.putImageData(d, 0, 0); const t = new THREE.CanvasTexture(c); t.flipY = b38.map.flipY; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
    out['Piloto'] = {...b38, map: t};
  }
  return out;
};

// Texturas de public/tex/ que se cargan en TEX (las que no existan se saltan). Las de NEAREST se ven pixeleadas.
const TEXTURAS = ['agua_azul', 'agua_verde', 'asfalto', 'asfalto2', 'cancha', 'cielo', 'cielo_foto', 'cielo_nubes', 'concreto', 'concreto_gris', 'concreto_suave', 'duela', 'fachada', 'fachada1', 'fachada2', 'ladrillo', 'losa', 'madera', 'pared', 'parquet', 'pasto', 'pasto2', 'pasto_px', 'piso_banco', 'pista', 'tapiz_amarillo', 'tapiz_durazno', 'tapiz_menta', 'toldo', 'valla', 'vidrio'];
const NEAREST = ['pasto', 'pasto_px'];

// Carga TODO una sola vez: personaje base, caras, variantes, texturas del escenario y la gente del paquete.
let promesa: Promise<Modelo> | null = null;
// Fotos (caras y texturas de foto) van en .jpg para que el kit pese poco; las texturas pixeladas, en .png. Se acepta cualquiera de los dos.
const imgJpgOPng = async (sinExt: string, primero: 'jpg' | 'png' = 'jpg') => {
  const [a, b] = primero === 'jpg' ? ['.jpg', '.png'] : ['.png', '.jpg'];
  try { return await img(staticFile(sinExt + a)); } catch { return await img(staticFile(sinExt + b)); }
};

const JPG_TEX = ['cielo_foto', 'cielo_nubes', 'concreto_suave'];

export const cargarModelo = (): Promise<Modelo> => promesa ??= (async () => {
  const gltf: any = await new Promise((res, rej) => new GLTFLoader().load(staticFile('modelo/beto.glb'), res, undefined, rej));
  const base = await img(staticFile('modelo/textura_original.png'));
  const tex: Record<string, THREE.CanvasTexture> = {};
  for (const k of CARAS) {
    let ci: HTMLImageElement | null = null; try { ci = await imgJpgOPng(`caras/${k}`); } catch { /* sin cara: queda la original */ }
    tex[k] = componer(base, ci, [186, 128, 90]);
  }
  for (const [k, cara, ropa, piel] of VARIANTES) {
    let ci: HTMLImageElement | null = null; try { ci = await imgJpgOPng(`caras/${cara}`); } catch { continue; }
    tex[k] = componer(base, ci, piel, ROPAS[ropa]);
  }
  for (const n of TEXTURAS) {
    let im: HTMLImageElement; try { im = await imgJpgOPng(`tex/${n}`, JPG_TEX.includes(n) ? 'jpg' : 'png'); } catch { continue; } const t = new THREE.Texture(im); t.needsUpdate = true;
    if (NEAREST.includes(n)) TEX[n] = nearest(t); else { t.colorSpace = THREE.SRGBColorSpace; t.magFilter = THREE.LinearFilter; t.minFilter = THREE.LinearMipmapLinearFilter; t.generateMipmaps = true; t.anisotropy = 8; TEX[n] = t; }
  }
  let pers: Record<string, Persona> = {}; try { pers = await cargarPersonas(gltf.scene); } catch (e) { console.error('personas', e); }
  return {scene: gltf.scene, tex, pers};
})();

// Reposo y mapa de retargeting
const L: [string, string, string, string?][] = [   // [hueso, origen Kimodo, destino Kimodo, hueso hijo en el modelo]
  ['DEF-spine', 'Hips', 'Spine1', 'DEF-spine.001'], ['DEF-spine.001', 'Spine1', 'Spine2', 'DEF-spine.002'], ['DEF-spine.002', 'Spine2', 'Chest', 'DEF-spine.003'],
  ['DEF-spine.003', 'Chest', 'Neck1', 'DEF-spine.004'], ['DEF-spine.004', 'Neck1', 'Neck2', 'DEF-spine.005'], ['DEF-spine.005', 'Neck2', 'Head', 'DEF-spine.006'], ['DEF-spine.006', 'Head', 'HeadEnd'],
  ...(['L', 'R'] as const).flatMap((s) => {
    const K = s === 'L' ? 'Left' : 'Right';
    return [
      [`DEF-shoulder.${s}`, `${K}Shoulder`, `${K}Arm`, `DEF-upper_arm.${s}`], [`DEF-upper_arm.${s}`, `${K}Arm`, `${K}ForeArm`, `DEF-forearm.${s}`],
      [`DEF-forearm.${s}`, `${K}ForeArm`, `${K}Hand`, `DEF-hand.${s}`], [`DEF-hand.${s}`, `${K}Hand`, `${K}HandMiddle1`],
      [`DEF-thigh.${s}`, `${K}Leg`, `${K}Shin`, `DEF-shin.${s}`], [`DEF-shin.${s}`, `${K}Shin`, `${K}Foot`, `DEF-foot.${s}`],
      [`DEF-foot.${s}`, `${K}Foot`, `${K}ToeBase`, `DEF-toe.${s}`], [`DEF-toe.${s}`, `${K}ToeBase`, `${K}ToeEnd`],
    ] as [string, string, string, string?][];
  }),
];
const TWIST: Record<string, string> = {'DEF-spine': 'Hips', 'DEF-spine.001': 'Hips', 'DEF-spine.002': 'Spine2', 'DEF-spine.003': 'Chest', 'DEF-spine.004': 'Chest', 'DEF-spine.005': 'Head', 'DEF-spine.006': 'Head'};

export type Rig = {armDir?: {pos: number[]; neg: number[]}; root: THREE.Object3D; bones: Record<string, THREE.Bone>; rest: Record<string, {wq: THREE.Quaternion; wp: THREE.Vector3; lq: THREE.Quaternion; lp: THREE.Vector3}>; mesh: THREE.SkinnedMesh};
export const crearRig = (m: Modelo): Rig => {
  const root = skClone(m.scene); root.updateMatrixWorld(true);
  const bones: Record<string, THREE.Bone> = {}; let mesh: THREE.SkinnedMesh | null = null;
  root.traverse((o: any) => { if (o.isBone) bones[o.name] = o; if (o.isSkinnedMesh) mesh = o; });
  const rest: Rig['rest'] = {};
  for (const [n, b] of Object.entries(bones)) rest[n] = {wq: b.getWorldQuaternion(new THREE.Quaternion()), wp: b.getWorldPosition(new THREE.Vector3()), lq: b.quaternion.clone(), lp: b.position.clone()};
  return {root, bones, rest, mesh: mesh!};
};

const V = (mov: Mov, n: string, f: number) => { const a = mov.P[n][f]; return new THREE.Vector3(a[0], a[1], a[2]); };
const Rm = (mov: Mov, n: string, f: number) => { const r = mov.R[n]?.[f]; if (!r) return null; return new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().set(r[0], r[1], r[2], 0, r[3], r[4], r[5], 0, r[6], r[7], r[8], 0, 0, 0, 0, 1)); };

const nm = (n: string) => n.replace(/\./g, '');
export const posar = (rig: Rig, mov: Mov, fr: number, escala = 0.94) => {
  const f = Math.min(Math.max(0, Math.round(fr)), mov.n - 1);
  const desired: Record<string, THREE.Quaternion> = {};
  for (const [b, a, z, hijo] of L) {
    const bone = rig.bones[nm(b)]; if (!bone || !mov.P[a] || !mov.P[z]) continue;
    const tdir = V(mov, z, f).sub(V(mov, a, f)).normalize();
    let rdir = hijo ? rig.rest[nm(hijo)].wp.clone().sub(rig.rest[nm(b)].wp).normalize() : new THREE.Vector3(0, 1, 0).applyQuaternion(rig.rest[nm(b)].wq);
    if (rig.armDir && /^DEF-(upper_arm|forearm|hand)\./.test(b)) { const a = rig.rest[nm(b)].wp.x >= 0 ? rig.armDir.pos : rig.armDir.neg; rdir = new THREE.Vector3(a[0], a[1], a[2]); }
    const arc = new THREE.Quaternion().setFromUnitVectors(rdir, tdir);
    let q = arc.clone().multiply(rig.rest[nm(b)].wq);
    const tw = TWIST[b];
    if (tw) {   // giro sobre el eje del hueso: hacia dónde mira el torso/cabeza según Kimodo
      const R = Rm(mov, tw, f);
      if (R) {
        const fwdT = new THREE.Vector3(0, 0, 1).applyQuaternion(R); fwdT.addScaledVector(tdir, -fwdT.dot(tdir)).normalize();
        const fwd0 = new THREE.Vector3(0, 0, 1).applyQuaternion(arc); fwd0.addScaledVector(tdir, -fwd0.dot(tdir)).normalize();
        const ang = Math.atan2(new THREE.Vector3().crossVectors(fwd0, fwdT).dot(tdir), fwd0.dot(fwdT));
        q = new THREE.Quaternion().setFromAxisAngle(tdir, ang).multiply(q);
      }
    }
    desired[nm(b)] = q;
  }
  // de mundo a local, padres primero
  const orden: THREE.Object3D[] = []; rig.root.traverse((o) => orden.push(o));
  const wq: Record<string, THREE.Quaternion> = {};
  for (const o of orden) {
    if (!(o as any).isBone) continue; const n = o.name; const par = o.parent as any;
    const pw = par && par.isBone ? wq[par.name] : new THREE.Quaternion();
    if (desired[n]) { (o as THREE.Bone).quaternion.copy(pw.clone().invert().multiply(desired[n])); wq[n] = desired[n]; }
    else { (o as THREE.Bone).quaternion.copy(rig.rest[n].lq); wq[n] = pw.clone().multiply(rig.rest[n].lq); }
  }
  const h = V(mov, 'Hips', f).multiplyScalar(escala);
  const sp = rig.bones['DEF-spine']; sp.position.set(h.x, h.y, h.z + rig.rest['DEF-spine'].lp.z);
  rig.root.updateMatrixWorld(true);
};

// ---------- el componente ----------
// modelo: lo que devuelve cargarModelo() · mov + f: clip y cuadro · persona: alguien del paquete (o 'Rojo' | 'Doctor' | 'Piloto')
// carita: cara de foto del personaje base (o una VARIANTE: 'verde' | 'doctor' | 'piloto' | 'mujer') · recorte: [yMin, yMax] corta la malla
// rayos: cuerpo transparente de un color (radiografía) · casco: casco de piloto en la cabeza
export const Beto3D: React.FC<{modelo: Modelo; mov: Mov; f: number; persona?: string; recorte?: [number, number]; carita?: Cara | string; pos?: [number, number, number]; rotY?: number; s?: number; rayos?: boolean; ajuste?: (r: Rig) => void; extra?: (r: Rig) => React.ReactNode; casco?: boolean; rayosColor?: string; rayosOp?: number}> = ({modelo, mov, f, persona, recorte, carita = 'neutral', pos = [0, 0, 0], rotY = 0, s = 1, rayos = false, ajuste, extra, casco, rayosColor = '#ff3b3b', rayosOp = 0.5}) => {
  const P = persona ? modelo.pers?.[persona] : undefined;
  const rig = React.useMemo(() => {
    const r = crearRig(modelo);
    const m = snap(new THREE.MeshBasicMaterial({map: modelo.tex.neutral, side: THREE.DoubleSide}));
    r.mesh.material = m; (r.mesh as any).frustumCulled = false;
    if (P) { r.mesh.geometry = P.geom; m.map = P.map; m.needsUpdate = true; }
    return r;
  }, [modelo, P]);
  posar(rig, mov, f);
  if (ajuste) { ajuste(rig); rig.root.updateMatrixWorld(true); }
  React.useLayoutEffect(() => {   // casco verde olivo con visera, pegado al hueso de la cabeza
    const hb = rig.bones['DEF-spine006']; if (!hb) return; const prev = hb.getObjectByName('casco'); if (prev) hb.remove(prev); if (!casco) return;
    const inv = new THREE.Vector3(); hb.getWorldScale(inv); const k = 1 / (inv.x || 1);
    const gr = new THREE.Group(); gr.name = 'casco';
    const m1 = new THREE.MeshLambertMaterial({color: '#56664a'}), m2 = new THREE.MeshLambertMaterial({color: '#2b2f2c'});
    const cap = new THREE.Mesh(new THREE.SphereGeometry(0.15, 18, 12, 0, Math.PI * 2, 0, Math.PI * 0.62), m1); cap.scale.set(1, 1.05, 1.1); cap.position.set(0, 0.07, -0.012);
    const vis = new THREE.Mesh(new THREE.SphereGeometry(0.142, 16, 8, -0.9, 1.8, Math.PI * 0.32, Math.PI * 0.12), m2); vis.position.set(0, 0.06, 0.0);
    gr.add(cap); gr.add(vis); gr.scale.setScalar(k); hb.add(gr);
  }, [rig, casco]);
  { const mt = rig.mesh.material as THREE.MeshBasicMaterial; mt.clippingPlanes = recorte ? [new THREE.Plane(new THREE.Vector3(0, -1, 0), recorte[1]), new THREE.Plane(new THREE.Vector3(0, 1, 0), -recorte[0])] : null; mt.needsUpdate = true; }
  { const mm = rig.mesh.material as THREE.MeshBasicMaterial; mm.color.set(rayos ? rayosColor : '#ffffff'); mm.transparent = rayos; mm.opacity = rayos ? rayosOp : 1; mm.depthWrite = !rayos; }
  if (!P) { (rig.mesh.material as THREE.MeshBasicMaterial).map = modelo.tex[carita] ?? modelo.tex.neutral; (rig.mesh.material as THREE.Material).needsUpdate = true; }
  { const mm = rig.mesh.material as any; if (rayos) { if (mm.__map === undefined) mm.__map = mm.map; mm.map = null; mm.needsUpdate = true; } else if (mm.__map !== undefined) { mm.map = mm.__map; mm.__map = undefined; mm.needsUpdate = true; } }
  return <group position={pos} rotation={[0, rotY, 0]} scale={s * (P ? P.alto / 1.81 : 1)}><primitive object={rig.root} />{extra ? extra(rig) : null}</group>;
};

// ---------- pose a mano (para usar dentro de `ajuste`) ----------
const V3 = THREE.Vector3;
// posición de un hueso en el espacio del personaje
export const bpos = (r: Rig, n: string) => { const b = r.bones[n]; if (!b) return new V3(); r.root.updateMatrixWorld(true); return r.root.worldToLocal(b.getWorldPosition(new V3())); };
// IK de dos huesos genérico: lleva el extremo de la cadena [b1, b2, b3] a Tl (espacio del personaje) con la articulación media hacia poleL.
// w mezcla con la pose del clip (0 = clip, 1 = IK completo). Sirve para brazos (upper_arm, forearm, hand) y piernas (thigh, shin, foot).
export const ik2 = (r: Rig, n: [string, string, string], Tl: THREE.Vector3, poleL: THREE.Vector3, w = 1) => {
  const ub = r.bones[n[0]], fb = r.bones[n[1]], hb = r.bones[n[2]]; if (!ub || !fb || !hb || w <= 0) return;
  r.root.updateMatrixWorld(true);
  const S = ub.getWorldPosition(new V3()), E = fb.getWorldPosition(new V3()), W = hb.getWorldPosition(new V3());
  const T = W.clone().lerp(r.root.localToWorld(Tl.clone()), w); const pole = poleL.clone().transformDirection(r.root.matrixWorld);
  const a = S.distanceTo(E), b = E.distanceTo(W); const D = T.clone().sub(S); let d = D.length(); const dir = D.normalize(); d = Math.min(Math.max(d, Math.abs(a - b) + 1e-3), a + b - 1e-3);
  const cosA = (a * a + d * d - b * b) / (2 * a * d); const sinA = Math.sqrt(Math.max(0, 1 - cosA * cosA));
  const perp = pole.clone().addScaledVector(dir, -pole.dot(dir)).normalize(); const El = S.clone().addScaledVector(dir, a * cosA).addScaledVector(perp, a * sinA);
  const gira = (bone: THREE.Object3D, from: THREE.Vector3, to: THREE.Vector3) => { const q = new THREE.Quaternion().setFromUnitVectors(from.normalize(), to.normalize()); const nw = q.multiply(bone.getWorldQuaternion(new THREE.Quaternion())); const pw = bone.parent!.getWorldQuaternion(new THREE.Quaternion()); bone.quaternion.copy(pw.invert().multiply(nw)); bone.updateMatrixWorld(true); };
  gira(ub, E.clone().sub(S), El.clone().sub(S)); const E2 = fb.getWorldPosition(new V3()), W2 = hb.getWorldPosition(new V3()); gira(fb, W2.sub(E2), T.clone().sub(E2));
};
// IK del brazo: mano a Tl con el codo hacia poleL
export const ikBrazo = (r: Rig, lado: 'L' | 'R', Tl: THREE.Vector3, poleL: THREE.Vector3, w = 1) => ik2(r, ['DEF-upper_arm' + lado, 'DEF-forearm' + lado, 'DEF-hand' + lado], Tl, poleL, w);
// las dos manos a la cabeza, con mezcla w
export const manosCabeza = (w: number, abre = 0.13, sube = 0.13) => (r: Rig) => {
  const H = bpos(r, 'DEF-spine006');
  ikBrazo(r, 'L', H.clone().add(new V3(abre, sube, 0.02)), new V3(1, -0.2, -0.3), w);
  ikBrazo(r, 'R', H.clone().add(new V3(-abre, sube, 0.02)), new V3(-1, -0.2, -0.3), w);
};
// gira la cabeza a ángulo a (radianes) sobre un eje local, con mezcla w
export const cabeza = (r: Rig, w: number, eje: 'x' | 'y' | 'z', a: number) => { const h = r.bones['DEF-spine006']; if (h && w) { h.rotateOnAxis(eje === 'x' ? new V3(1, 0, 0) : eje === 'y' ? new V3(0, 1, 0) : new V3(0, 0, 1), a * w); h.updateMatrixWorld(true); } };

// ---------- carga de recursos para una composición ----------
// ids: clips de public/mov/ que se usan. Devuelve {movs, mod}; mientras no estén, Remotion espera (delayRender).
export const useRecursos = (ids: string[]) => {
  const [movs, setMovs] = React.useState<Record<string, Mov>>({});
  const [mod, setMod] = React.useState<Modelo | null>(null);
  const [h1] = React.useState(() => delayRender('movs')); const [h2] = React.useState(() => delayRender('modelo'));
  React.useEffect(() => {
    Promise.all(ids.map(id => fetch(staticFile(`mov/${id}.json`)).then(r => (r.ok ? r.json() : null)).catch(() => null).then(j => [id, j] as const)))
      .then(rs => { const o: Record<string, Mov> = {}; rs.forEach(([id, j]) => { if (j) o[id] = j; }); setMovs(o); continueRender(h1); });
    cargarModelo().then(m => { setMod(m); continueRender(h2); }).catch(e => { console.error(e); continueRender(h2); });
  }, []);
  return {movs, mod};
};
// cuadro del clip m para el cuadro f del plano: v = velocidad, o = desfase (se queda dentro del clip)
export const cuadro = (m: Mov, f: number, v = 1, o = 0) => Math.min(Math.max(0, Math.floor(f * v + o)), m.n - 1);
