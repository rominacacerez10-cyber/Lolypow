// Caras de foto del protagonista.
// Cada cara es una imagen en public/caras/<nombre>.png (vertical, ancho:alto ≈ 0.62, el cabello toca el borde de arriba
// y la barbilla el de abajo). Se pega encima del rectángulo de la cara de la textura del personaje base (ver Beto3D.tsx).
// Para una expresión nueva: crea la imagen con el mismo encuadre, guárdala en public/caras/ y agrégala a CARAS.

export type Cara = 'neutral' | 'feliz' | 'susto' | 'llanto' | 'cansado' | 'serio';
export const CARAS: Cara[] = ['neutral', 'feliz', 'susto', 'llanto', 'cansado', 'serio'];

// Variantes del personaje base con otra cara, otra ropa y otro tono de piel.
// [nombre de la variante, archivo de cara, ropa (ver ROPAS en Beto3D.tsx), color de piel RGB]
export const VARIANTES: [string, string, string, [number, number, number]][] = [
  ['verde', 'verde', 'verde', [230, 190, 160]],
  ['doctor', 'doctor', 'bata', [120, 80, 55]],
  ['piloto', 'piloto', 'piloto', [200, 150, 110]],
  ['mujer', 'mujer', 'azul', [235, 200, 175]],
];
