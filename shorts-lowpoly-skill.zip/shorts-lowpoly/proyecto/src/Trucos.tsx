// TRUCOS que ya funcionaron y sirven para cualquier short:
// - Hoyo en el piso con stencil (PisoHoyo + Hoyo): el piso deja de dibujarse donde está el hoyo y abajo hay un pozo negro.
// - TechoRoto: techo que se rompe en cuadritos alrededor de un hueco (por el hueco se ve el cielo).
// - CaidaCiudad: el personaje cae hacia una ciudad vista desde el aire; la cámara cae con él.
// - golpe(): caída contra el piso con rebote chico; las grietas, el temblor de cámara y las piedritas salen DESPUÉS del golpe.
// - Piedritas, Polvo, salto() y pico() para saltos e impactos.
// Regla: nada se rompe antes de tiempo; lo que provoca el golpe (grietas, polvo, pedazos) aparece en el cuadro del impacto o después.
import React from 'react';
import * as THREE from 'three';
import {Beto3D, Rig, Modelo, Mov, cabeza} from './Beto3D';
import {tmat, TEX} from './props';
import {Cam, Pl} from './Set';
import {CiudadReal} from './Ciudad';
import {clamp, smooth} from './util';

const V3 = THREE.Vector3;
export const rr = (i: number, k: number) => { const x = Math.sin(i * 91.7 + k * 17.3) * 43758.5453; return x - Math.floor(x); };

// ======================================================================
// 1) HOYO EN EL PISO (stencil). El <Gl> ya trae stencil:true.
//    <PisoHoyo t="parquet" hoyo={<Hoyo c={[x, z]} t={0..1} />} />
//    - Hoyo: celdas MASK (no pintan color, escriben 1 en el stencil, renderOrder −10) + pozo negro (BackSide) abajo.
//    - PisoHoyo: el piso se dibuja solo donde el stencil NO es 1 (renderOrder −5).
//    - La forma es asimétrica y de cuadritos (se ve «roto», no un círculo perfecto). t de 0 a 1 la hace crecer.
// ======================================================================
const MASK = new THREE.MeshBasicMaterial({colorWrite: false, depthWrite: false, stencilWrite: true, stencilRef: 1, stencilFunc: THREE.AlwaysStencilFunc, stencilZPass: THREE.ReplaceStencilOp});
const NEGRO_POZO = new THREE.MeshBasicMaterial({color: '#050505', side: THREE.BackSide});
const radioHoyo = (a: number) => 0.78 * (1 + 0.26 * Math.sin(2 * a + 0.7) + 0.17 * Math.sin(3 * a + 2.1) + 0.1 * Math.sin(5 * a + 0.3) + 0.06 * Math.sin(7 * a + 1.3));
export const Hoyo: React.FC<{c: [number, number]; t: number; cel?: number; escala?: number}> = ({c, t, cel = 0.07, escala = 1}) => {
  const g = React.useMemo(() => {
    const pos: number[] = []; const N = Math.ceil(1.6 * escala / cel);
    for (let i = -N; i <= N; i++) for (let j = -N; j <= N; j++) { const x = i * cel, z = j * cel; const a = Math.atan2(z, x); if (Math.hypot(x, z * 1.1) < radioHoyo(a) * t * escala) { const h = cel / 2 + 0.002; pos.push(x - h, 0, z - h, x - h, 0, z + h, x + h, 0, z + h, x - h, 0, z - h, x + h, 0, z + h, x + h, 0, z - h); } }
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); return geo;
  }, [Math.round(t * 60), cel, escala]);
  if (t <= 0) return null;
  return (<group position={[c[0], 0.001, c[1]]}>
    <mesh geometry={g} material={MASK} renderOrder={-10} />
    <mesh material={NEGRO_POZO} position={[0, -1.6, 0]}><boxGeometry args={[3.4 * escala, 3.2, 3.4 * escala]} /></mesh>
  </group>);
};
export const PisoHoyo: React.FC<{hoyo?: React.ReactNode; t?: string; w?: number; d?: number; ts?: number; z?: number}> = ({hoyo, t = 'parquet', w = 14, d = 18, ts = 1.5, z = 0.5}) => {
  const m = React.useMemo(() => { const x = (tmat(t, w / ts, d / ts) as THREE.Material).clone(); x.stencilWrite = true; x.stencilRef = 1; x.stencilFunc = THREE.NotEqualStencilFunc; x.stencilZPass = THREE.KeepStencilOp; return x; }, [t, w, d, ts]);
  return (<>{hoyo}<mesh position={[0, 0, z]} rotation={[-Math.PI / 2, 0, 0]} material={m} renderOrder={-5}><planeGeometry args={[w, d]} /></mesh></>);
};

// ======================================================================
// 2) TECHO QUE SE ROMPE EN CUADRITOS (visto desde abajo).
//    Techo horizontal a `alto` m; alrededor del hueco (hx, hz) hay una cuadrícula de cuadritos de 7 cm que se caen
//    del centro hacia afuera a partir del cuadro F0 (en ~4 cuadros). Los cuadritos del borde quedan blancos (yeso)
//    y cada borde roto lleva su canto. Arriba del techo hay cielo (solo se ve por el hueco).
//    F = cuadro actual. zPared = pared del fondo (el techo empieza ahí).
// ======================================================================
const CEL = 0.07, NC = 30;
export const TechoRoto: React.FC<{hx: number; hz: number; F: number; F0: number; alto?: number; zPared?: number; tex?: string}> = ({hx, hz, F, F0, alto = 2.45, zPared = -2.5, tex = 'concreto_suave'}) => {
  const HC = alto;
  const g = React.useMemo(() => {
    const x0 = hx - (NC * CEL) / 2, z0 = hz - (NC * CEL) / 2;
    const rect = new THREE.Shape([new THREE.Vector2(-15, zPared), new THREE.Vector2(15, zPared), new THREE.Vector2(15, 9), new THREE.Vector2(-15, 9)]);
    rect.holes.push(new THREE.Path([new THREE.Vector2(x0, z0), new THREE.Vector2(x0, z0 + NC * CEL), new THREE.Vector2(x0 + NC * CEL, z0 + NC * CEL), new THREE.Vector2(x0 + NC * CEL, z0)]));
    // ¿qué cuadritos se caen y en qué cuadro? (forma alargada hacia la cámara y con ruido: asimétrica)
    const abre = (i: number, j: number) => {
      const cx = x0 + (i + 0.5) * CEL - hx, cz = z0 + (j + 0.5) * CEL - hz; const a = Math.atan2(cz, cx);
      const rx = 0.43, rz = cz > 0 ? 0.66 : 0.32;
      const ruido = 1 + 0.22 * Math.sin(a * 3 + 1.3) + 0.12 * Math.sin(a * 7 + 0.4) + (rr(i * 31 + j, 3) - 0.5) * 0.35;
      const d = Math.hypot(cx / rx, cz / rz) / ruido;
      return d < 1 ? F0 + Math.floor(d * 3 + rr(i, j) * 2.5) : 1e9;
    };
    const abierto = (i: number, j: number) => i >= 0 && j >= 0 && i < NC && j < NC && F >= abre(i, j);
    const conc: number[] = [], uvC: number[] = [], yeso: number[] = [], canto: number[] = [];
    const quad = (arr: number[], a: number[], b: number[], c: number[], d: number[]) => arr.push(...a, ...b, ...c, ...a, ...c, ...d);
    const TH = 0.13;
    for (let i = 0; i < NC; i++) for (let j = 0; j < NC; j++) {
      const xa = x0 + i * CEL, xb = xa + CEL, za = z0 + j * CEL, zb = za + CEL;
      if (abierto(i, j)) {
        if (!abierto(i - 1, j)) quad(canto, [xa, HC, za], [xa, HC + TH, za], [xa, HC + TH, zb], [xa, HC, zb]);
        if (!abierto(i + 1, j)) quad(canto, [xb, HC, za], [xb, HC + TH, za], [xb, HC + TH, zb], [xb, HC, zb]);
        if (!abierto(i, j - 1)) quad(canto, [xa, HC, za], [xa, HC + TH, za], [xb, HC + TH, za], [xb, HC, za]);
        if (!abierto(i, j + 1)) quad(canto, [xa, HC, zb], [xa, HC + TH, zb], [xb, HC + TH, zb], [xb, HC, zb]);
        continue;
      }
      let cerca = 0; for (let di = -2; di <= 2; di++) for (let dj = -2; dj <= 2; dj++) if (abierto(i + di, j + dj)) cerca = Math.max(cerca, 3 - Math.max(Math.abs(di), Math.abs(dj)));
      const blanco = cerca >= 2 ? rr(i * 7 + j, 5) < 0.8 : cerca === 1 ? rr(i * 7 + j, 6) < 0.35 : false;
      if (blanco) quad(yeso, [xa, HC - 0.002, za], [xb, HC - 0.002, za], [xb, HC - 0.002, zb], [xa, HC - 0.002, zb]);
      else { quad(conc, [xa, HC, za], [xb, HC, za], [xb, HC, zb], [xa, HC, zb]); uvC.push(xa, za, xb, za, xb, zb, xa, za, xb, zb, xa, zb); }
    }
    const geo = (pos: number[], uv?: number[]) => { const q = new THREE.BufferGeometry(); q.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3)); if (uv) q.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2)); return q; };
    return {techo: new THREE.ShapeGeometry(rect), conc: geo(conc, uvC), yeso: geo(yeso), canto: geo(canto)};
  }, [Math.min(F, F0 + 8), F0, hx, hz, HC, zPared]);
  const mat = React.useMemo(() => {
    if (!TEX[tex]) return new THREE.MeshBasicMaterial({color: '#bdbab4', side: THREE.DoubleSide});
    const t = TEX[tex].clone(); t.wrapS = t.wrapT = THREE.MirroredRepeatWrapping; t.repeat.set(1.1, 1.1); t.needsUpdate = true; return new THREE.MeshBasicMaterial({map: t, side: THREE.DoubleSide});
  }, [tex]);
  return (
    <>
      <mesh geometry={g.techo} material={mat} position={[0, HC, 0]} rotation={[Math.PI / 2, 0, 0]} />
      <mesh geometry={g.conc} material={mat} />
      <mesh geometry={g.yeso}><meshBasicMaterial color="#f2eee6" side={THREE.DoubleSide} /></mesh>
      <mesh geometry={g.canto}><meshBasicMaterial color="#d3ccbf" side={THREE.DoubleSide} /></mesh>
      <Pl p={[0, HC + 6, -12]} w={90} h={70} r={[Math.PI / 2, 0, 0]} t="cielo" ts={14} basic />
    </>
  );
};

// ======================================================================
// 3) CAÍDA SOBRE LA CIUDAD (va dentro de un <Gl fog={['#c2ccd7', 70, 260]}>).
//    La cámara baja con aceleración (y = y0 − 0.3·f − 0.0025·f²), inclinada `pitch` rad hacia abajo;
//    el personaje va 1.45 m delante de la cámara y 0.2 m abajo, de espaldas a ella, agitando brazos y piernas.
//    Usa el clip «cae_brazos» (cuadro 22) + `agita` para que se vea vivo.
// ======================================================================
export const CaidaCiudad: React.FC<{f: number; mod: Modelo; mov: Mov; persona?: string; carita?: string; y0?: number; pitch?: number; fov?: number}> = ({f, mod, mov, persona, carita, y0 = 31, pitch = 0.6, fov = 74}) => {
  const y = y0 - f * 0.3 - 0.0025 * f * f;
  const C = new V3(0.05 * Math.sin(f * 1.9), y, 14 + 0.04 * Math.sin(f * 2.3)); const T = new V3(0, 0, 14 - y / Math.tan(pitch)); const dir = T.clone().sub(C).normalize();
  const fw = dir.clone().negate(); const up0 = new V3(0, 1, 0); const u = up0.clone().addScaledVector(fw, -fw.dot(up0)).normalize(); const x = u.clone().cross(fw);
  const Bp = C.clone().addScaledVector(dir, 1.45).addScaledVector(u, -0.2);
  const q = new THREE.Quaternion().setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, u, fw)).multiply(new THREE.Quaternion().setFromAxisAngle(new V3(0, 0, 1), 0.06 * Math.sin(f * 0.35)));
  const agita = (r: Rig) => {
    cabeza(r, 1, 'x', -0.45 + 0.06 * Math.sin(f * 0.5));
    const L = r.bones['DEF-upper_armL'], R = r.bones['DEF-upper_armR'], tl = r.bones['DEF-thighL'], tr = r.bones['DEF-thighR'];
    if (L) L.rotateZ(0.28 * Math.sin(f * 0.6)); if (R) R.rotateZ(-0.28 * Math.sin(f * 0.6 + 0.5));
    if (tl) tl.rotateX(0.18 * Math.sin(f * 0.5)); if (tr) tr.rotateX(-0.18 * Math.sin(f * 0.5 + 0.8));
  };
  return (<>
    <Cam pos={[C.x, C.y, C.z]} look={[T.x, T.y, T.z]} fov={fov} />
    <CiudadReal />
    <group position={Bp} quaternion={q}><group position={[0, -0.95, 0]}><Beto3D modelo={mod} mov={mov} f={Math.min(22, mov.n - 1)} persona={persona} carita={carita} ajuste={agita} /></group></group>
  </>);
};

// ======================================================================
// 4) GOLPE CONTRA EL PISO. golpe(f, F_PEGA) devuelve:
//    y      altura del cuerpo: cae desde `alto` m (y = alto·(1 − (f/F)²)), pega en F_PEGA y da un rebote chico
//    sacude amplitud del temblor de cámara: SOLO 7 cuadros desde el golpe (mueve la posición de la cámara, no el giro)
//    grieta 0→1 en 5 cuadros desde el golpe (para <GrietasDecal s={tam * (0.2 + 0.8 * grieta)} />)
//    tau    segundos desde el golpe (para <Piedritas t={tau} />)
//    sombra 0→1 antes del golpe (la sombra crece mientras cae)
// ======================================================================
export const golpe = (f: number, F: number, alto = 2.35) => ({
  y: f < F ? 0.03 + alto * (1 - (f / F) ** 2) : 0.03 + 0.05 * Math.exp(-(f - F) / 2.5) * Math.abs(Math.sin((f - F) * 1.2)),
  sacude: f >= F && f < F + 7 ? 0.035 * (1 - (f - F) / 7) : 0,
  grieta: f < F ? 0 : smooth(clamp((f - F) / 5)),
  tau: Math.max(0, f - F) / 30,
  sombra: clamp(f / F),
  pego: f >= F,
});
// piedritas que saltan del punto del golpe (t = segundos desde el golpe)
export const Piedritas: React.FC<{t: number; n?: number; c?: [number, number]; r?: number; colores?: [string, string]}> = ({t, n = 30, c = [0, 0], r = 1, colores = ['#ececea', '#d2d2cf']}) => {
  if (t <= 0) return null;
  return (<>{Array.from({length: n}).map((_, i) => { const a = rr(i, 81) * Math.PI * 2, d = (0.55 + rr(i, 82) * 0.95) * r; const s = 0.025 + rr(i, 83) * 0.035; const k = 0.25 + 0.75 * Math.min(1, t * 5);
    const yy = Math.max(0.03, 0.03 + (1.2 + rr(i, 84) * 1.4) * t - 4.9 * t * t);
    return <mesh key={i} position={[c[0] + Math.cos(a) * d * k, yy, c[1] + Math.sin(a) * d * 1.3 * k]} rotation={[rr(i, 85) * 3 + t * 9, rr(i, 86) * 3, 0]} scale={[s * 1.3, s * 0.6, s]}><dodecahedronGeometry args={[1, 0]} /><meshLambertMaterial color={i % 4 ? colores[0] : colores[1]} flatShading /></mesh>; })}</>);
};

// ======================================================================
// 5) SALTOS Y POLVO
// ======================================================================
// altura de un salto entre los cuadros a y b, de altura h (arco de seno)
export const salto = (f: number, a: number, b: number, h: number) => (f > a && f < b ? h * Math.sin(Math.PI * (f - a) / (b - a)) : 0);
// 1 en el cuadro c y 0 a w cuadros de distancia (para doblar rodillas al despegar / aterrizar)
export const pico = (f: number, c: number, w = 3) => Math.max(0, 1 - Math.abs(f - c) / w);
// nubecitas de polvo en los pies (f = cuadros desde que toca el piso; x = posiciones en x de los pies)
export const Polvo: React.FC<{f: number; x: number[]; n?: number; k?: number; dur?: number; z?: number}> = ({f, x, n = 7, k = 1, dur = 26, z = 0}) => {
  if (f < 0 || f > dur) return null; const t = f / dur;
  return (<>{x.flatMap((x0, j) => Array.from({length: n}).map((_, i) => { const a = rr(i + j * 9, 31) * Math.PI * 2; const v = (0.12 + rr(i + j * 9, 32) * 0.2) * Math.sqrt(k);
    const s = k * (0.014 + rr(i + j * 9, 33) * 0.022) * (0.6 + 1.6 * t) * (1 - t * t);
    return <mesh key={j + '_' + i} position={[x0 + Math.cos(a) * v * t, 0.03 + (0.06 + rr(i, 34) * 0.12) * Math.sin(Math.PI * Math.min(1, t * 1.6)), z + 0.05 + Math.sin(a) * v * t]} rotation={[a, a * 2, 0]} scale={[s, s * 0.8, s]}><icosahedronGeometry args={[1, 0]} /><meshLambertMaterial color="#f1eee8" /></mesh>; }))}</>);
};
