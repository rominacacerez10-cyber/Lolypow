// Look PS1: snap() hace que los vértices «tiemblen» pegados a una rejilla de pantalla (como en la PlayStation 1);
// nearest() deja una textura con píxeles duros; Ps1 es un lienzo alterno que dibuja a 540×960 y lo amplía ×2 sin suavizar.
import React from 'react';
import * as THREE from 'three';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';

export const W = 540, H = 960;

export const snap = <T extends THREE.Material>(mat: T, strength = 0.28): T => {
  mat.onBeforeCompile = (sh) => {
    sh.vertexShader = sh.vertexShader.replace(
      '#include <project_vertex>',
      `#include <project_vertex>
       vec2 g = vec2(${(W / 2 / strength).toFixed(1)}, ${(H / 2 / strength).toFixed(1)});
       gl_Position.xy = floor(gl_Position.xy / gl_Position.w * g + 0.5) / g * gl_Position.w;`
    );
  };
  return mat;
};

export const lambert = (color: string | number, extra: any = {}) =>
  snap(new THREE.MeshLambertMaterial({color, flatShading: true, ...extra}));

export const nearest = (t: THREE.Texture) => {
  t.magFilter = THREE.NearestFilter; t.minFilter = THREE.NearestFilter; t.generateMipmaps = false;
  t.colorSpace = THREE.SRGBColorSpace; t.needsUpdate = true; return t;
};

export const Ps1: React.FC<{children: React.ReactNode; cam?: any; bg?: string; fog?: [string, number, number]}> = ({children, cam, bg = '#9ec7ea', fog}) => (
  <div style={{width: 1080, height: 1920, position: 'relative', background: bg, overflow: 'hidden'}}>
    <div style={{width: W, height: H, transform: 'scale(2)', transformOrigin: '0 0'}}>
      <ThreeCanvas width={W} height={H} dpr={1} gl={{antialias: false}} camera={cam ?? {fov: 48, near: 0.05, far: 300, position: [0, 1.5, 4]}}
        style={{imageRendering: 'pixelated', width: W, height: H}}>
        <color attach="background" args={[bg]} />
        {fog ? <fog attach="fog" args={fog} /> : null}
        <ambientLight intensity={1.15} />
        <directionalLight position={[3, 6, 4]} intensity={1.6} />
        {children}
      </ThreeCanvas>
    </div>
  </div>
);

// Cámara controlada por código: posición, objetivo y fov por cuadro.
export const Cam: React.FC<{pos: [number, number, number]; look: [number, number, number]; fov?: number; roll?: number}> = ({pos, look, fov = 48, roll = 0}) => {
  const {camera} = useThree();
  React.useLayoutEffect(() => {
    const c: any = camera;
    c.position.set(...pos); c.fov = fov; c.up.set(Math.sin(roll), Math.cos(roll), 0); c.lookAt(...look); c.updateProjectionMatrix();
  });
  return null;
};
