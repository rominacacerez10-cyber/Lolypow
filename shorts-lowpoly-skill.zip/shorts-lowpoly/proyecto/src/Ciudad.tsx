// Ciudad hecha en código (sin descargar nada):
// - Edificio: caja con fachada de concreto (café, beige o blanco) y cuadrícula de ventanas azules, algunas encendidas.
//   La fachada se dibuja en un canvas con el número exacto de pisos y columnas.
// - Farol: farol negro victoriano.
// - CalleEdificios: fila de edificios para el fondo de una calle.
// - CiudadReal: ciudad completa vista desde el aire (manzanas, banquetas, parques), con InstancedMesh para que sea rápida.
import React from 'react';
import * as THREE from 'three';

const rnd = (i: number, k: number) => { const x = Math.sin(i * 127.1 + k * 311.7) * 43758.5453; return x - Math.floor(x); };
export type Tono = 'cafe' | 'beige' | 'blanco';
const BASE: Record<Tono, [string, string]> = {cafe: ['#6f5d4f', '#5c4b3f'], beige: ['#b89b77', '#a58866'], blanco: ['#e6ebf1', '#d6dde6']};
const VENT: Record<Tono, [string, string]> = {cafe: ['#5a84c2', '#f2eedf'], beige: ['#5f88c6', '#f2eedf'], blanco: ['#6d97d2', '#f7f8fb']};
const cacheTex: Record<string, THREE.Texture> = {};
const fachada = (tono: Tono, cols: number, pisos: number, seed: number) => {
  const key = `${tono}_${cols}_${pisos}_${seed}`; if (cacheTex[key]) return cacheTex[key];
  const C = 48; const c = document.createElement('canvas'); c.width = cols * C; c.height = pisos * C; const g = c.getContext('2d')!;
  g.fillStyle = BASE[tono][0]; g.fillRect(0, 0, c.width, c.height);
  for (let i = 0; i < c.width * c.height / 40; i++) { g.fillStyle = rnd(i, seed) > 0.5 ? BASE[tono][1] : (tono === 'blanco' ? '#f3f6f9' : '#86735f'); g.globalAlpha = 0.35; g.fillRect(rnd(i, seed + 1) * c.width, rnd(i, seed + 2) * c.height, 2, 2); }
  g.globalAlpha = 1;
  const wf = tono === 'blanco' ? 0.62 : 0.56, hf = tono === 'blanco' ? 0.5 : 0.6;
  for (let x = 0; x < cols; x++) for (let y = 0; y < pisos; y++) {
    const on = rnd(x * 31 + y, seed + 7) < (tono === 'blanco' ? 0.2 : 0.14);
    g.fillStyle = VENT[tono][on ? 1 : 0]; g.fillRect(x * C + C * (1 - wf) / 2, y * C + C * (1 - hf) / 2, C * wf, C * hf);
  }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; t.magFilter = THREE.NearestFilter; cacheTex[key] = t; return t;
};

// Edificio con la base en p (y = suelo); w (x), h, d (z)
export const Edificio: React.FC<{p: [number, number, number]; w: number; h: number; d?: number; pisos: number; cols: number; tono: Tono; seed?: number; rotY?: number}> = ({p, w, h, d = w, pisos, cols, tono, seed = 1, rotY = 0}) => {
  const mats = React.useMemo(() => {
    const fr = new THREE.MeshLambertMaterial({map: fachada(tono, cols, pisos, seed)});
    const colsL = Math.max(2, Math.round(cols * d / w));
    const la = new THREE.MeshLambertMaterial({map: fachada(tono, colsL, pisos, seed + 3)});
    const techo = new THREE.MeshLambertMaterial({color: BASE[tono][1]});
    return [la, la, techo, techo, fr, fr];
  }, [tono, cols, pisos, seed, w, d]);
  return <mesh position={[p[0], p[1] + h / 2, p[2]]} rotation={[0, rotY, 0]} material={mats}><boxGeometry args={[w, h, d]} /></mesh>;
};

// Farol negro victoriano: base, poste, travesaño y linterna con vidrio claro y tapa en punta
const NEG = new THREE.MeshLambertMaterial({color: '#141414'});
const VID = new THREE.MeshBasicMaterial({color: '#f4f0dc'});
export const Farol: React.FC<{p: [number, number, number]; s?: number; rotY?: number}> = ({p, s = 1, rotY = 0}) => (
  <group position={p} scale={s} rotation={[0, rotY, 0]}>
    <mesh material={NEG} position={[0, 0.25, 0]}><cylinderGeometry args={[0.16, 0.22, 0.5, 10]} /></mesh>
    <mesh material={NEG} position={[0, 2.2, 0]}><cylinderGeometry args={[0.055, 0.075, 3.6, 10]} /></mesh>
    <mesh material={NEG} position={[0, 3.55, 0]}><boxGeometry args={[0.9, 0.05, 0.05]} /></mesh>
    <mesh material={NEG} position={[0, 4.05, 0]}><cylinderGeometry args={[0.2, 0.12, 0.08, 4]} /></mesh>
    <mesh material={VID} position={[0, 4.35, 0]} rotation={[0, Math.PI / 4, 0]}><cylinderGeometry args={[0.24, 0.17, 0.55, 4]} /></mesh>
    {[0, 1, 2, 3].map(i => <mesh key={i} material={NEG} position={[Math.cos(i * Math.PI / 2) * 0.19, 4.35, Math.sin(i * Math.PI / 2) * 0.19]}><boxGeometry args={[0.04, 0.58, 0.04]} /></mesh>)}
    <mesh material={NEG} position={[0, 4.75, 0]} rotation={[0, Math.PI / 4, 0]}><coneGeometry args={[0.3, 0.32, 4]} /></mesh>
    <mesh material={NEG} position={[0, 4.97, 0]}><sphereGeometry args={[0.05, 8, 6]} /></mesh>
  </group>
);

// Fila de 5 edificios alternando beige y café, a la profundidad z (fondo de una calle)
export const CalleEdificios: React.FC<{z: number}> = ({z}) => (<>
  {([[-11, 'beige', 9, 14], [-5.5, 'cafe', 14, 22], [0.5, 'beige', 11, 16], [6.5, 'cafe', 16, 24], [12, 'beige', 10, 15]] as [number, Tono, number, number][]).map(([x, t, h, pisos], i) =>
    <Edificio key={i} p={[x, 0, z - (i % 2) * 2]} w={5.6} h={h} d={5} pisos={pisos} cols={6} tono={t} seed={i + 3} />)}
</>);

// ---------- ciudad vista desde el aire ----------
// caja con sombreado fijo por cara (arriba claro, lados más oscuros) para que los edificios se vean definidos sin luces
const CAJA_SOMB = (() => { const g = new THREE.BoxGeometry(1, 1, 1); const k = [0.8, 0.66, 1.0, 0.5, 0.9, 0.72]; const c: number[] = []; for (let f = 0; f < 6; f++) for (let v = 0; v < 4; v++) c.push(k[f], k[f], k[f]); g.setAttribute('color', new THREE.Float32BufferAttribute(c, 3)); return g; })();
const CIUDAD_M = new THREE.MeshBasicMaterial({color: '#ffffff', vertexColors: true});
type Bloque = {x: number; y: number; z: number; w: number; h: number; d: number; c: THREE.Color};
const instancias = (L: Bloque[]) => {
  const m = new THREE.InstancedMesh(CAJA_SOMB, CIUDAD_M, Math.max(1, L.length)); const o = new THREE.Object3D();
  L.forEach((b, i) => { o.position.set(b.x, b.y, b.z); o.scale.set(b.w, b.h, b.d); o.updateMatrix(); m.setMatrixAt(i, o.matrix); m.setColorAt(i, b.c); });
  m.count = L.length; m.instanceMatrix.needsUpdate = true; if (m.instanceColor) m.instanceColor.needsUpdate = true; m.frustumCulled = false; return m;
};
const rr = (i: number, k: number) => { const x = Math.sin(i * 91.7 + k * 17.3) * 43758.5453; return x - Math.floor(x); };
// Manzanas de 15 m con calles de 5 m (de x = −135 a 135 y de z = −270 a 60), banquetas, 10 % de parques; edificios de 2 a 11 m.
export const CiudadReal: React.FC = () => {
  const {edif, banq, parques} = React.useMemo(() => {
    const cols = ['#f4f6f9', '#e8dcc6', '#cdd8e4', '#f6efe3', '#bccad9', '#dde2e8', '#eee6d6', '#d9cbb2'].map(c => new THREE.Color(c));
    const E: Bloque[] = [], S: Bloque[] = [], PQ: Bloque[] = []; const M = 15, CALLE = 5;
    for (let i = -9; i <= 9; i++) for (let j = -18; j <= 4; j++) {
      const k = (i + 20) * 61 + (j + 30); const x0 = i * M, z0 = j * M; const inner = M - CALLE;
      S.push({x: x0, y: 0.06, z: z0, w: inner + 1.4, h: 0.12, d: inner + 1.4, c: new THREE.Color('#b9bab6')});
      if (rr(k, 1) < 0.1) { PQ.push({x: x0, y: 0.14, z: z0, w: inner, h: 0.04, d: inner, c: new THREE.Color('#6cb04f')}); continue; }
      const nx = 2 + Math.floor(rr(k, 2) * 2), nz = 2 + Math.floor(rr(k, 3) * 2);
      for (let a = 0; a < nx; a++) for (let b = 0; b < nz; b++) { const q = k * 13 + a * 5 + b; if (rr(q, 4) < 0.15) continue;
        const w = inner / nx - 0.45, d = inner / nz - 0.45; const h = 2 + Math.pow(rr(q, 5), 2.2) * 9;
        E.push({x: x0 - inner / 2 + (a + 0.5) * inner / nx, y: 0.12 + h / 2, z: z0 - inner / 2 + (b + 0.5) * inner / nz, w: w * (0.8 + rr(q, 6) * 0.2), h, d: d * (0.8 + rr(q, 7) * 0.2), c: cols[Math.floor(rr(q, 8) * cols.length)]}); }
    }
    return {edif: instancias(E), banq: instancias(S), parques: instancias(PQ)};
  }, []);
  return (<>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, -90]}><planeGeometry args={[420, 420]} /><meshBasicMaterial color="#5e6267" /></mesh>
    <primitive object={banq} /><primitive object={parques} /><primitive object={edif} />
  </>);
};
