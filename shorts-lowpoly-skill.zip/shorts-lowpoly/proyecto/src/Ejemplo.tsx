// SHORT DE EJEMPLO (~13.7 s, 1080×1920, 30 fps, sin voz): 9 planos de ~1.5 s que muestran lo que trae el kit.
// Cada plano es una función r(p) que devuelve un <Gl> (escena three.js) + un subtítulo amarillo chico.
// Para hacer TU short: copia este archivo, cambia la lista PLANOS (duración, subtítulo y escena de cada plano)
// y registra la composición en Root.tsx.
import React from 'react';
import * as THREE from 'three';
import {AbsoluteFill, Sequence, useCurrentFrame} from 'remotion';
import {Beto3D, Rig, Modelo, Mov, useRecursos, cuadro, bpos, ikBrazo, cabeza} from './Beto3D';
import {Caja, Piso} from './props';
import {Gl, cam, Cam, Pl} from './Set';
import {Obj, useModelos} from './Modelos';
import {CalleEdificios, Farol} from './Ciudad';
import {CieloFoto, Pasto, ArbolBB, Sombra, CuadroPaisaje, RelojNum, Pedazos, GrietasDecal, EstrellasMareo} from './Utileria';
import {PisoHoyo, Hoyo, CaidaCiudad, golpe, Piedritas} from './Trucos';
import {clamp, smooth} from './util';

const V3 = THREE.Vector3;
// clips de public/mov/ que usa este short
const IDS = ['saluda', 'camina', 'sentado', 'agacha_brazos', 'cae_brazos', 'tendido_espalda', 'mira', 'manos_cadera', 'salta_feliz', 'celebra', 'susto', 'sorpresa'];

export type P = {f: number; n: number; mov: (id: string) => Mov; mod: Modelo};
type Plano = {n: number; sub: string; subDesde?: number; r: (p: P) => React.ReactNode};

// personaje: id del clip + opciones (v = velocidad del clip, o = cuadro inicial, fr = cuadro fijo)
type BO = {f?: number; fr?: number; v?: number; o?: number; pos?: [number, number, number]; rotY?: number; s?: number; persona?: string; carita?: string; ajuste?: (r: Rig) => void; extra?: (r: Rig) => React.ReactNode};
const B = (p: P, id: string, o: BO = {}) => {
  const m = p.mov(id);
  return <Beto3D modelo={p.mod} mov={m} f={o.fr ?? cuadro(m, o.f ?? p.f, o.v ?? 1, o.o ?? 0)} pos={o.pos} rotY={o.rotY} s={o.s} persona={o.persona} carita={o.carita} ajuste={o.ajuste} extra={o.extra} />;
};
const mira = (de: [number, number], a: [number, number]) => Math.atan2(a[0] - de[0], a[1] - de[1]);   // rotY para que alguien en `de` mire hacia `a`

// ---------- escenarios ----------
// jardín: cielo de foto, pasto claro, valla de madera, árboles de hojas y (opcional) gnomo
export const Jardin: React.FC<{valla?: number; gnomo?: [number, number, number] | null; cielo?: [number, number, number]; cieloW?: number}> = ({valla = -4.5, gnomo = [2.7, 0, -3.2], cielo = [0, 14, -48], cieloW = 120}) => (<>
  <CieloFoto p={cielo} w={cieloW} />
  <Pasto />
  <Pl p={[0, 0.95, valla]} w={60} h={1.9} t="valla" ts={1.0} basic tint="#d9d4cc" />
  <Caja s={[60, 0.07, 0.06]} c="#9b9488" p={[0, 1.62, valla + 0.04]} /><Caja s={[60, 0.07, 0.06]} c="#9b9488" p={[0, 0.45, valla + 0.04]} />
  <ArbolBB p={[-5.5, 0, valla - 3]} h={6.5} seed={1} /><ArbolBB p={[4.8, 0, valla - 4]} h={7.5} seed={2} /><ArbolBB p={[-13, 0, valla - 6]} h={7} seed={3} /><ArbolBB p={[12, 0, valla - 5]} h={6} seed={4} /><ArbolBB p={[0.5, 0, valla - 9]} h={8} seed={5} />
  {gnomo && <Obj n="gnomo" alto={0.42} p={gnomo} rotY={-0.3} />}
</>);
// calle: banqueta, edificios de fondo, faroles y cielo de foto
export const Calle: React.FC<{z?: number}> = ({z = -14}) => (<>
  <CieloFoto p={[0, 16, -50]} w={140} />
  <Piso w={60} d={40} t="concreto_suave" ts={3.5} tint="#cdc6b8" />
  <Caja s={[60, 0.012, 0.13]} c="#e3c12c" p={[0, 0.006, -1.6]} />
  <CalleEdificios z={z} />
  <Farol p={[-2.6, 0, -3.5]} s={0.8} /><Farol p={[3.2, 0, -4.2]} s={0.8} />
</>);

// ---------- 2 · vecinos comiendo alrededor de una mesa en el jardín ----------
const TC: [number, number] = [-0.15, -2.2];
const VECINOS: {pe: string; x: number; z: number; ph: number}[] = [
  {pe: 'Character_38_Female', x: -1.15, z: -2.15, ph: 0}, {pe: 'Character_Male_36', x: -0.2, z: -3.3, ph: 3.1}, {pe: 'Character_46_Female', x: 0.82, z: -2.6, ph: 4.4},
];
// comer: la mano derecha va a la boca y regresa; la izquierda descansa en la mesa
const come = (f: number, ph: number) => (r: Rig) => {
  const H = bpos(r, 'DEF-spine006'); const w = smooth(clamp(Math.sin(f * 0.21 + ph) * 1.6 + 0.3));
  ikBrazo(r, 'R', H.clone().add(new V3(-0.04, -0.08, 0.13)), new V3(-1, -0.6, 0), w);
  ikBrazo(r, 'L', new V3(0.2, 0.8, 0.45), new V3(1, -0.4, -0.3), 0.85);
  cabeza(r, 1, 'x', 0.12 + 0.08 * w);
};
// saludar desde la silla: mano derecha arriba, moviéndose de lado a lado
const saludaSentado = (f: number) => (r: Rig) => {
  const H = bpos(r, 'DEF-spine006');
  ikBrazo(r, 'R', H.clone().add(new V3(-0.3 + 0.08 * Math.sin(f * 0.5), 0.32, 0.12)), new V3(-1, -0.3, -0.2), 1);
  ikBrazo(r, 'L', new V3(0.2, 0.8, 0.45), new V3(1, -0.4, -0.3), 0.85);
};
const MesaJardin: React.FC<{p: P}> = ({p}) => (<>
  <mesh position={[TC[0], 0.6, TC[1]]}><cylinderGeometry args={[0.8, 0.86, 0.38, 44]} /><meshLambertMaterial color="#f5f3ee" /></mesh>
  <mesh position={[TC[0], 0.21, TC[1]]}><cylinderGeometry args={[0.32, 0.44, 0.42, 20]} /><meshLambertMaterial color="#4a2e1a" /></mesh>
  <Obj n="pastel" alto={0.17} p={[TC[0] + 0.02, 0.79, TC[1] - 0.05]} />
  <Obj n="botellas" alto={0.3} p={[TC[0] + 0.15, 0.79, TC[1] + 0.3]} rotY={0.3} />
  {VECINOS.map((c, i) => { const ry = mira([c.x, c.z], TC); const d = 0.62 / Math.hypot(TC[0] - c.x, TC[1] - c.z);
    return (<React.Fragment key={i}>
      <Obj n="silla" alto={0.98} p={[c.x - Math.sin(ry) * 0.12, 0, c.z - Math.cos(ry) * 0.12]} rotY={ry} recolor="#ffffff" brillo={1.75} />
      {B(p, 'sentado', {fr: 20, pos: [c.x, 0, c.z], rotY: ry, persona: c.pe, ajuste: i === 0 ? saludaSentado(p.f) : come(p.f, c.ph)})}
      <Obj n="plato" ancho={0.24} p={[c.x + (TC[0] - c.x) * (1 - d) * 0.42, 0.785, c.z + (TC[1] - c.z) * (1 - d) * 0.42]} />
    </React.Fragment>); })}
</>);

// ---------- 3 · sala con piso que se rompe ----------
const F_ROMPE = 19;
const BC: [number, number] = [0.02, -0.25];

// ---------- 5 · golpe ----------
const F_PEGA = 10;

// ---------- los planos ----------
export const PLANOS: Plano[] = [
  // 0 · presentación: medio cuerpo, saluda en la calle; atrás pasa una vecina
  {n: 45, sub: 'Este es Beto.', r: (p) => (
    <Gl bg="#9ec7ea">
      {cam(p.f, p.n, [0.35, 1.45, 3.0], [0.3, 1.45, 2.75], [0, 1.3, 0], 42)}
      <Calle />
      {B(p, 'camina', {pos: [0.8 + p.f * 0.03, 0, -3.0], rotY: Math.PI / 2, persona: 'Character_41_Female', o: 20})}
      {B(p, 'saluda', {pos: [0, 0, 0], carita: 'feliz', o: 18})}
      <Sombra p={[0.05, 0, 0]} w={0.9} d={0.55} />
    </Gl>
  )},
  // 1 · camina por el jardín; la cámara lo sigue despacio
  {n: 45, sub: 'Puede caminar…', r: (p) => { const x = -1.0 + p.f * 0.03; const cx = -0.2 + x * 0.5; return (
    <Gl bg="#8fbde9">
      <Cam pos={[cx, 1.3, 5.6]} look={[cx, 1.05, 0]} fov={46} />
      <Jardin gnomo={[1.6, 0, -2.4]} />
      {B(p, 'camina', {pos: [x, 0, 0], rotY: Math.PI / 2, v: 0.95, o: 10, carita: 'neutral'})}
      <Sombra p={[x + 0.2, 0, -0.2]} w={1.1} d={0.5} rot={0.5} />
    </Gl>
  ); }},
  // 2 · saluda a los vecinos que comen en el jardín (gente del paquete, comiendo con IK)
  {n: 45, sub: '…saludar a sus vecinos…', r: (p) => (
    <Gl bg="#8fbde9">
      {cam(p.f, p.n, [0.6, 1.9, 2.6], [0.55, 1.88, 2.4], [0.1, 0.95, -2.0], 56)}
      <Jardin valla={-5.2} gnomo={[-2.4, 0, -4.2]} />
      <MesaJardin p={p} />
      {B(p, 'saluda', {pos: [0.95, 0, -1.05], rotY: mira([0.95, -1.05], TC), o: 18})}
      <Sombra p={[1.0, 0, -1.1]} w={0.9} d={0.5} />
      <Obj n="planta" alto={0.9} p={[-2.0, 0, -3.4]} />
    </Gl>
  )},
  // 3 · en la sala: se agacha, salta y AHÍ se rompe el piso (hoyo asimétrico con stencil + pedazos de parquet)
  {n: 50, sub: '…romper el piso de su casa…', r: (p) => {
    const f = p.f; const tr = Math.max(0, f - F_ROMPE) / 30; const th = smooth(clamp((f - F_ROMPE) / 6));
    const cae = f < F_ROMPE ? 0.06 * Math.sin(Math.PI * clamp((f - 14) / 5)) : Math.max(-1.6, 0.12 * Math.sin(Math.min(1, tr * 6) * Math.PI / 2) - 3.2 * tr * tr);
    return (
      <Gl bg="#e8d880">
        {cam(f, p.n, [0, 4.4, 1.6], [0, 4.3, 1.5], [0, 0.1, -1.25], 54)}
        <Pl p={[0, 1.6, -4.4]} w={12} h={3.2} t="tapiz_durazno" ts={1.25} basic /><Pl p={[0, 4.6, -4.41]} w={12} h={2.8} c="#a19f9b" basic />
        <Caja s={[12, 0.12, 0.05]} c="#7a4a26" p={[0, 0.06, -4.37]} />
        <PisoHoyo t="parquet" hoyo={<Hoyo c={BC} t={th} />} />
        <CuadroPaisaje p={[-1.3, 2.25, -4.36]} w={0.5} h={0.38} /><RelojNum p={[1.25, 2.7, -4.36]} r={0.19} f={f + 300} />
        <Obj n="planta" alto={0.85} p={[-2.2, 0, -3.8]} />
        <Obj n="silla" alto={0.98} p={[1.7, 0, -3.3]} rotY={-0.4} recolor="#ffffff" brillo={1.75} />
        {f < F_ROMPE ? B(p, 'agacha_brazos', {pos: [0, 0, BC[1] + 0.05], fr: Math.round(18 + f * 2.0), carita: 'serio'}) : B(p, 'cae_brazos', {pos: [0, cae, BC[1] + 0.05], fr: 22, carita: 'susto'})}
        {f < F_ROMPE && <Sombra p={[0, 0, BC[1] + 0.05]} w={0.9} d={0.7} />}
        <Pedazos c={BC} r={0.5} n={18} t={tr} tam={0.13} v={2.4} />
        <Pedazos c={BC} r={0.7} n={10} t={tr * 0.8} tam={0.08} v={1.6} seed={9} colores={['#d8b07a', '#a8783f']} />
      </Gl>
    );
  }},
  // 4 · cae desde muy alto hacia la ciudad: la cámara cae con él
  {n: 50, sub: '…y caer desde un edificio.', r: (p) => (
    <Gl bg="#b4c3d2" fog={['#c2ccd7', 70, 260]}>
      <CaidaCiudad f={p.f} mod={p.mod} mov={p.mov('cae_brazos')} carita="susto" />
    </Gl>
  )},
  // 5 · ¡PUM!: vista desde arriba; cae, PEGA en el cuadro 10 y DESPUÉS: temblor (7 cuadros), grietas que crecen y piedritas
  {n: 40, sub: '¡PUM!', subDesde: F_PEGA, r: (p) => {
    const f = p.f; const g = golpe(f, F_PEGA); const sx = g.sacude * Math.sin(f * 7), sz = g.sacude * Math.cos(f * 9);
    const agita = (r: Rig) => { if (g.pego) return; const L = r.bones['DEF-upper_armL'], R = r.bones['DEF-upper_armR']; if (L) L.rotateZ(0.3 * Math.sin(f * 0.9)); if (R) R.rotateZ(-0.3 * Math.sin(f * 0.9)); };
    return (
      <Gl bg="#7a746c">
        <Cam pos={[sx, 3.7 - 0.08 * smooth(f / p.n), 0.02 + sz]} look={[sx, 0, sz]} fov={52} />
        <Pl p={[0, 0, 0]} w={30} h={30} r={[-Math.PI / 2, 0, 0]} t="asfalto2" ts={2.2} basic tint="#b8b2a8" />
        {[-6, -3.6, 2.4, 4.8].map((z, i) => <Caja key={i} s={[0.12, 0.01, 1.4]} c="#f2f2f2" p={[0.02, 0.01, z]} />)}
        <Caja s={[1.4, 0.012, 0.18]} c="#f0d030" p={[-1.35, 0.012, 0.15]} />
        {!g.pego && <Sombra p={[0, 0, 0.05]} w={0.6 + 1.2 * g.sombra} d={0.5 + 1.6 * g.sombra} />}
        {g.grieta > 0 && <GrietasDecal p={[0, 0, 0.1]} s={3.6 * (0.2 + 0.8 * g.grieta)} op={Math.min(1, g.grieta * 2)} />}
        {B(p, 'tendido_espalda', {pos: [0, g.y, 0.05], fr: 60, carita: g.pego ? 'llanto' : 'susto', ajuste: agita})}
        <Piedritas t={g.tau} />
      </Gl>
    );
  }},
  // 6 · primer plano de la cara: mareado, con estrellas girando cerca de la cabeza
  {n: 45, sub: 'Auch.', r: (p) => {
    const f = p.f; const mareo = (r: Rig) => { cabeza(r, 1, 'z', 0.16 * Math.sin(f * 0.3)); cabeza(r, 1, 'x', 0.06 * Math.sin(f * 0.23 + 1)); };
    const HY = 1.63;
    return (
      <Gl bg="#9ec7ea">
        {cam(f, p.n, [0.03, HY + 0.02, 1.3], [0.02, HY + 0.02, 1.2], [0, HY - 0.1, 0], 42)}
        <Calle />
        {B(p, 'mira', {fr: 0, pos: [0, 0, 0], carita: 'cansado', ajuste: mareo})}
        <EstrellasMareo c={new V3(0, HY + 0.17, 0.02)} r={0.24} f={f} n={5} s={0.05} />
      </Gl>
    );
  }},
  // 7 · los vecinos se acercan a ver; él sigue tirado en su hoyito con grietas
  {n: 45, sub: 'Los vecinos se asoman.', r: (p) => {
    const f = p.f; const C: [number, number] = [0, 0.4];
    const G: {pe: string; x: number; z: number; id: string; o: number}[] = [
      {pe: 'Character_Male_35', x: -1.15, z: -0.35, id: 'susto', o: 40}, {pe: 'Character_46_Female', x: 1.2, z: -0.2, id: 'manos_cadera', o: 10}, {pe: 'Character_Male_43', x: 0.1, z: -0.95, id: 'sorpresa', o: 70},
    ];
    return (
      <Gl bg="#9ec7ea">
        {cam(f, p.n, [0.2, 2.5, 4.4], [0.15, 2.45, 4.15], [0, 0.55, 0], 50)}
        <Calle z={-16} />
        <GrietasDecal p={[C[0], 0.006, C[1]]} s={2.6} op={0.9} />
        {B(p, 'tendido_espalda', {fr: 60, pos: [C[0], 0.03, C[1]], carita: 'cansado'})}
        <Piedritas t={0.6} c={C} r={0.8} n={18} />
        {G.map((g, i) => <React.Fragment key={i}>{B(p, g.id, {pos: [g.x, 0, g.z], rotY: mira([g.x, g.z], C), persona: g.pe, o: g.o, v: 0.6})}<Sombra p={[g.x, 0, g.z]} w={0.8} d={0.45} /></React.Fragment>)}
      </Gl>
    );
  }},
  // 8 · cierre: feliz en el jardín
  {n: 45, sub: 'Hecho con Claude Code', r: (p) => (
    <Gl bg="#8fbde9">
      {cam(p.f, p.n, [0, 1.35, 3.6], [0, 1.35, 3.3], [0, 1.15, 0], 44)}
      <Jardin gnomo={[1.3, 0, -1.6]} />
      {B(p, 'salta_feliz', {pos: [0, 0, 0], carita: 'feliz', o: 30})}
      <Sombra p={[0.05, 0, 0]} w={0.9} d={0.55} />
    </Gl>
  )},
];
export const INICIOS = PLANOS.reduce<number[]>((a, s, i) => [...a, i ? a[i - 1] + PLANOS[i - 1].n : 0], []);
export const TOTAL = PLANOS.reduce((a, s) => a + s.n, 0);

// ---------- subtítulo amarillo chico ----------
const FUENTE = "'Arial Rounded MT Bold','Trebuchet MS','Helvetica Neue',Arial,sans-serif";
export const Sub: React.FC<{text: string}> = ({text}) => (
  <div style={{position: 'absolute', left: 60, right: 60, top: 1290, textAlign: 'center', fontFamily: FUENTE, fontWeight: 900, fontSize: 44, lineHeight: 1.1, color: '#e6e82e', WebkitTextStroke: '7px #1a1d00', paintOrder: 'stroke fill' as any, letterSpacing: 1}}>{text}</div>
);

const UnPlano: React.FC<{i: number; fo?: number; mov: (id: string) => Mov; mod: Modelo}> = ({i, fo, mov, mod}) => {
  const f0 = useCurrentFrame(); const f = fo ?? f0; const s = PLANOS[i];
  return <AbsoluteFill>{s.r({f, n: s.n, mov, mod})}{f >= (s.subDesde ?? 0) && <Sub text={s.sub} />}</AbsoluteFill>;
};
const useListo = () => {
  const {movs, mod} = useRecursos(IDS); const okM = useModelos();
  const listo = !!mod && okM && IDS.every(id => movs[id]);
  return {listo, mov: (id: string) => movs[id], mod: mod!};
};

// Composición completa
export const Ejemplo: React.FC = () => {
  const {listo, mov, mod} = useListo();
  if (!listo) return null;
  return (
    <AbsoluteFill style={{background: '#000'}}>
      {PLANOS.map((s, i) => <Sequence key={i} from={INICIOS[i]} durationInFrames={s.n}><UnPlano i={i} mov={mov} mod={mod} /></Sequence>)}
    </AbsoluteFill>
  );
};

// Cuadros sueltos para revisar rápido: SEL = cuadros GLOBALES del short (uno por plano). Cada cuadro de EjemploSel es uno de la lista.
export const SEL = [20, 70, 112, 160, 205, 250, 290, 340, 390];
export const EjemploSel: React.FC = () => {
  const {listo, mov, mod} = useListo(); const f0 = useCurrentFrame();
  if (!listo) return null;
  const F = SEL[Math.min(f0, SEL.length - 1)]; let i = 0; while (i + 1 < PLANOS.length && INICIOS[i + 1] <= F) i++;
  return <AbsoluteFill style={{background: '#000'}}><UnPlano i={i} fo={F - INICIOS[i]} mov={mov} mod={mod} /></AbsoluteFill>;
};
