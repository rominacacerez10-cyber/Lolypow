// Utilería hecha en código (canvas + three.js), lista para cualquier escena:
// cielo de foto, pasto claro pixeleado, árboles de hojas sueltas, sombras suaves, cuadro con paisaje,
// reloj de pared con números, velocímetro con números, terrones de tierra redondos, pedazos que salen volando,
// grietas que se ramifican, mazo de madera y estrellas de mareo.
import React from 'react';
import * as THREE from 'three';
import {TEX} from './props';

const rr = (i: number, k: number) => { const x = Math.sin(i * 91.7 + k * 17.3) * 43758.5453; return x - Math.floor(x); };
const cv = (w: number, h: number, draw: (g: CanvasRenderingContext2D) => void) => { const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d')!); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8; return t; };
const memo = <T,>(f: () => T) => { let v: T | null = null; return () => (v ??= f()); };
const FONT = "'Arial Rounded MT Bold','Trebuchet MS','Helvetica Neue',Arial,sans-serif";

// ---------- cielo de foto (TEX['cielo_foto'], proporción 2.26:1; si no está, azul liso) ----------
const matCielo = memo(() => new THREE.MeshBasicMaterial({map: TEX['cielo_foto'] ?? null, color: TEX['cielo_foto'] ? '#ffffff' : '#8fbde9', depthWrite: false, fog: false}));
export const CieloFoto: React.FC<{p: [number, number, number]; w: number; r?: [number, number, number]}> = ({p, w, r = [0, 0, 0]}) => (
  <mesh position={p} rotation={r} material={matCielo()} renderOrder={-20}><planeGeometry args={[w, w / 2.26]} /></mesh>
);

// ---------- pasto claro (verde claro; de cerca se ve pixeleado) ----------
const texPasto = memo(() => { const t = cv(256, 256, (g) => {
  g.fillStyle = '#76c040'; g.fillRect(0, 0, 256, 256);
  const cols = ['#5daa31', '#8dd04f', '#6bba3a', '#9edb61', '#529d2b', '#7fc845', '#68b236'];
  for (let i = 0; i < 6000; i++) { g.fillStyle = cols[Math.floor(rr(i, 11) * cols.length)]; g.fillRect(Math.floor(rr(i, 12) * 256), Math.floor(rr(i, 13) * 256), 1 + Math.floor(rr(i, 14) * 2), 2 + Math.floor(rr(i, 15) * 4)); }
}); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.magFilter = THREE.NearestFilter; return t; });
const mPasto: Record<string, THREE.Material> = {};
export const Pasto: React.FC<{w?: number; d?: number; rep?: number; p?: [number, number, number]}> = ({w = 90, d = 70, rep = 1.2, p = [0, 0, 0]}) => {
  const k = `${w}|${d}|${rep}`;
  const m = mPasto[k] ??= (() => { const t = texPasto().clone(); t.repeat.set(w / rep, d / rep); t.needsUpdate = true; return new THREE.MeshBasicMaterial({map: t}); })();
  return <mesh position={p} rotation={[-Math.PI / 2, 0, 0]} material={m}><planeGeometry args={[w, d]} /></mesh>;
};

// ---------- árbol de hojas sueltas (imagen recortada en canvas, siempre de frente) ----------
const texArbol = (seed: number) => { const t = cv(512, 640, (g) => {
  const tips: [number, number][] = []; let k = seed * 100;
  const rama = (x: number, y: number, a: number, L: number, w: number, d: number) => {
    const x2 = x + Math.cos(a) * L, y2 = y - Math.sin(a) * L;
    g.strokeStyle = d > 3 ? '#6e5a44' : '#7d6a52'; g.lineWidth = w; g.lineCap = 'round'; g.beginPath(); g.moveTo(x, y); g.quadraticCurveTo((x + x2) / 2 + (rr(k++, 3) - 0.5) * L * 0.3, (y + y2) / 2, x2, y2); g.stroke();
    if (d > 0) { const n = d > 3 ? 2 : 2 + (rr(k++, 4) > 0.6 ? 1 : 0); for (let i = 0; i < n; i++) rama(x2, y2, a + (i - (n - 1) / 2) * (0.5 + rr(k++, 5) * 0.35) + (rr(k++, 6) - 0.5) * 0.25, L * (0.68 + rr(k++, 7) * 0.12), w * 0.66, d - 1); }
    else tips.push([x2, y2]);
  };
  rama(256 + (rr(seed, 1) - 0.5) * 30, 640, Math.PI / 2 + (rr(seed, 2) - 0.5) * 0.15, 190, 22, 5);
  const verdes = ['#3f7a2a', '#4f8e33', '#5f9f3c', '#73b04a', '#86bf57', '#9acb66'];
  for (const capa of [0, 1, 2]) tips.forEach(([x, y], i) => { for (let j = 0; j < 9; j++) {
    const q = i * 31 + j * 7 + capa * 1000; g.fillStyle = verdes[Math.min(5, capa * 2 + Math.floor(rr(q, 8) * 2))]; g.globalAlpha = 0.95;
    g.beginPath(); g.ellipse(x + (rr(q, 9) - 0.5) * 70 - capa * 6, y + (rr(q, 10) - 0.5) * 50 - capa * 8, 7 + rr(q, 11) * 9, 5 + rr(q, 12) * 6, rr(q, 13) * 3, 0, 7); g.fill();
  } });
  g.globalAlpha = 1;
}); t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; return t; };
const mArbol: Record<number, THREE.Material> = {};
export const ArbolBB: React.FC<{p: [number, number, number]; h?: number; seed?: number}> = ({p, h = 5, seed = 1}) => {
  const m = mArbol[seed] ??= new THREE.MeshBasicMaterial({map: texArbol(seed), transparent: true, alphaTest: 0.35, side: THREE.DoubleSide});
  return <mesh position={[p[0], p[1] + h / 2, p[2]]} material={m}><planeGeometry args={[h * 0.8, h]} /></mesh>;
};

// ---------- sombra suave en el piso ----------
const texSombra = memo(() => cv(128, 128, (g) => { const gr = g.createRadialGradient(64, 64, 2, 64, 64, 64); gr.addColorStop(0, 'rgba(0,0,0,.42)'); gr.addColorStop(0.6, 'rgba(0,0,0,.22)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = gr; g.fillRect(0, 0, 128, 128); }));
const matSombra = memo(() => new THREE.MeshBasicMaterial({map: texSombra(), transparent: true, depthWrite: false}));
export const Sombra: React.FC<{p: [number, number, number]; w?: number; d?: number; rot?: number}> = ({p, w = 0.9, d = 0.6, rot = 0}) => (
  <mesh position={[p[0], p[1] + 0.006, p[2]]} rotation={[-Math.PI / 2, 0, rot]} material={matSombra()} renderOrder={2}><planeGeometry args={[w, d]} /></mesh>
);

// ---------- cuadro con paisaje (marco dorado) ----------
const texPaisaje = memo(() => cv(256, 192, (g) => {
  const s = g.createLinearGradient(0, 0, 0, 120); s.addColorStop(0, '#9fb6c4'); s.addColorStop(1, '#e3d7b4'); g.fillStyle = s; g.fillRect(0, 0, 256, 192);
  g.fillStyle = '#6f7d4e'; g.beginPath(); g.moveTo(0, 120); g.quadraticCurveTo(80, 80, 150, 112); g.quadraticCurveTo(210, 96, 256, 108); g.lineTo(256, 192); g.lineTo(0, 192); g.fill();
  g.fillStyle = '#4e5a33'; g.beginPath(); g.moveTo(0, 150); g.quadraticCurveTo(120, 128, 256, 150); g.lineTo(256, 192); g.lineTo(0, 192); g.fill();
  for (let i = 0; i < 5; i++) { g.fillStyle = '#3a4526'; g.beginPath(); g.ellipse(40 + i * 45, 118 - (i % 2) * 6, 12, 22, 0, 0, 7); g.fill(); g.fillStyle = '#4a3a26'; g.fillRect(38 + i * 45, 132 - (i % 2) * 6, 4, 12); }
  g.fillStyle = 'rgba(80,60,30,.25)'; g.fillRect(0, 0, 256, 192);
}));
const matPaisaje = memo(() => new THREE.MeshBasicMaterial({map: texPaisaje()}));
const MARCO = new THREE.MeshLambertMaterial({color: '#8a6a32', emissive: '#2a1e08'});
export const CuadroPaisaje: React.FC<{p: [number, number, number]; w?: number; h?: number}> = ({p, w = 0.56, h = 0.42}) => (
  <group position={p}><mesh material={MARCO}><boxGeometry args={[w + 0.1, h + 0.1, 0.04]} /></mesh><mesh material={matPaisaje()} position={[0, 0, 0.022]}><planeGeometry args={[w, h]} /></mesh></group>
);

// ---------- reloj de pared con números ----------
const texReloj = memo(() => cv(256, 256, (g) => {
  g.fillStyle = '#fbfaf6'; g.beginPath(); g.arc(128, 128, 124, 0, 7); g.fill();
  g.strokeStyle = '#222'; g.lineWidth = 3;
  for (let i = 0; i < 60; i++) { const a = i / 60 * Math.PI * 2, r0 = i % 5 ? 112 : 104; g.lineWidth = i % 5 ? 2 : 4; g.beginPath(); g.moveTo(128 + Math.sin(a) * r0, 128 - Math.cos(a) * r0); g.lineTo(128 + Math.sin(a) * 118, 128 - Math.cos(a) * 118); g.stroke(); }
  g.fillStyle = '#1d1d1d'; g.font = `900 30px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  for (let i = 1; i <= 12; i++) { const a = i / 12 * Math.PI * 2; g.fillText(String(i), 128 + Math.sin(a) * 84, 130 - Math.cos(a) * 84); }
}));
const matReloj = memo(() => new THREE.MeshBasicMaterial({map: texReloj()}));
const ARO = new THREE.MeshLambertMaterial({color: '#3a3a3a'}), MANE = new THREE.MeshBasicMaterial({color: '#151515'}), SEG = new THREE.MeshBasicMaterial({color: '#c62f2f'});
export const RelojNum: React.FC<{p: [number, number, number]; r?: number; f?: number}> = ({p, r = 0.2, f = 0}) => {
  const ms = 10 * 60 + 8 + f / 30, h = ms / 3600 * Math.PI * 2 * 5, m = ms / 60 * Math.PI * 2, s = (f / 30) * Math.PI * 2 / 6;
  return (
    <group position={p}>
      <mesh material={matReloj()} position={[0, 0, 0.012]}><circleGeometry args={[r, 40]} /></mesh>
      <mesh material={ARO}><torusGeometry args={[r, r * 0.09, 8, 40]} /></mesh>
      <mesh material={MANE} position={[Math.sin(h) * r * 0.25, Math.cos(h) * r * 0.25, 0.02]} rotation={[0, 0, -h]}><boxGeometry args={[r * 0.07, r * 0.5, 0.004]} /></mesh>
      <mesh material={MANE} position={[Math.sin(m) * r * 0.36, Math.cos(m) * r * 0.36, 0.022]} rotation={[0, 0, -m]}><boxGeometry args={[r * 0.045, r * 0.72, 0.004]} /></mesh>
      <mesh material={SEG} position={[Math.sin(s) * r * 0.36, Math.cos(s) * r * 0.36, 0.024]} rotation={[0, 0, -s]}><boxGeometry args={[r * 0.02, r * 0.78, 0.004]} /></mesh>
      <mesh material={MANE} position={[0, 0, 0.026]}><circleGeometry args={[r * 0.06, 12]} /></mesh>
    </group>
  );
};

// ---------- velocímetro con números (0 a 160) ----------
const A0 = -2.25, A1 = 2.25;   // ángulo (desde arriba, horario) de 0 y de 160
const texVelo = memo(() => cv(512, 512, (g) => {
  g.fillStyle = '#4b4c50'; g.beginPath(); g.arc(256, 256, 250, 0, 7); g.fill();
  g.fillStyle = '#3f4044'; g.beginPath(); g.arc(256, 256, 228, 0, 7); g.fill();
  g.strokeStyle = '#f2f2f2'; g.lineCap = 'butt';
  for (let i = 0; i <= 32; i++) { const a = A0 + (A1 - A0) * i / 32, g8 = i % 4 === 0; g.lineWidth = g8 ? 7 : 3; const r0 = g8 ? 178 : 192; g.beginPath(); g.moveTo(256 + Math.sin(a) * r0, 256 - Math.cos(a) * r0); g.lineTo(256 + Math.sin(a) * 214, 256 - Math.cos(a) * 214); g.stroke(); }
  g.fillStyle = '#f4f4f4'; g.font = `700 46px ${FONT}`; g.textAlign = 'center'; g.textBaseline = 'middle';
  for (let v = 0; v <= 160; v += 40) { const a = A0 + (A1 - A0) * v / 160; g.fillText(String(v), 256 + Math.sin(a) * 138, 258 - Math.cos(a) * 138); }
}));
const matVelo = memo(() => new THREE.MeshBasicMaterial({map: texVelo()}));
const AGUJA = new THREE.MeshBasicMaterial({color: '#f0863a'});
export const VelocimetroNum: React.FC<{v: number; r?: number}> = ({v, r = 1.75}) => {
  const a = A0 + (A1 - A0) * Math.min(1, Math.max(0, v / 160));
  return (
    <group>
      <mesh material={matVelo()}><circleGeometry args={[r, 64]} /></mesh>
      <group position={[0, 0, 0.03]} rotation={[0, 0, -a]}><mesh material={AGUJA} position={[0, r * 0.32, 0]}><boxGeometry args={[r * 0.045, r * 0.68, 0.01]} /></mesh></group>
      <mesh material={AGUJA} position={[0, 0, 0.04]}><circleGeometry args={[r * 0.07, 20]} /></mesh>
    </group>
  );
};

// ---------- terrones de tierra redondeados (piedras de caras planas, café) ----------
const ICO0 = new THREE.IcosahedronGeometry(1, 0); const DODE = new THREE.DodecahedronGeometry(1, 0);
const TIERRA = ['#7b4a28', '#8d5a33', '#6c3f22', '#94633b'].map(c => new THREE.MeshLambertMaterial({color: c, flatShading: true}));
// anillo de terrones alrededor de (cx, cz). crece: 0 → no hay nada; 1 → montón completo
export const Terrones: React.FC<{c: [number, number]; r: number; n?: number; crece: number; tam?: number; y?: number; seed?: number}> = ({c, r, n = 18, crece, tam = 0.12, y = 0, seed = 3}) => {
  if (crece <= 0) return null;
  return (<>{Array.from({length: n}).map((_, i) => {
    const a = (i / n) * Math.PI * 2 + rr(i, seed) * 0.5; const d = r * (0.8 + rr(i, seed + 1) * 0.45);
    const t = Math.min(1, Math.max(0, crece * 1.4 - rr(i, seed + 2) * 0.4)); if (t <= 0) return null;
    const s = tam * (0.55 + rr(i, seed + 3) * 0.8) * t;
    return <mesh key={i} geometry={i % 2 ? ICO0 : DODE} material={TIERRA[i % 4]} position={[c[0] + Math.cos(a) * d, y + s * 0.45, c[1] + Math.sin(a) * d]} rotation={[rr(i, seed + 4) * 3, rr(i, seed + 5) * 3, rr(i, seed + 6) * 3]} scale={[s * (1 + rr(i, seed + 7) * 0.4), s * 0.75, s]} />;
  })}</>);
};

// ---------- pedazos de piso que salen volando (astillas de parquet / concreto) ----------
export const Pedazos: React.FC<{c: [number, number]; r: number; n?: number; t: number; colores?: string[]; tam?: number; v?: number; seed?: number; y0?: number}> = ({c, r, n = 16, t, colores = ['#c79a63', '#b5834c', '#dcb27a'], tam = 0.12, v = 2.6, seed = 5, y0 = 0}) => {
  const mats = React.useMemo(() => colores.map(x => new THREE.MeshLambertMaterial({color: x, flatShading: true})), [colores.join()]);
  if (t <= 0) return null;
  return (<>{Array.from({length: n}).map((_, i) => {
    const a = (i / n) * Math.PI * 2 + rr(i, seed) * 0.6; const vu = v * (0.55 + rr(i, seed + 1) * 0.7), vo = 0.5 + rr(i, seed + 2) * 0.8;
    const d = r * (0.85 + rr(i, seed + 3) * 0.3) + vo * t; const yy = y0 + vu * t - 4.9 * t * t; const s = tam * (0.6 + rr(i, seed + 4) * 0.8);
    return <mesh key={i} geometry={ICO0} material={mats[i % mats.length]} position={[c[0] + Math.cos(a) * d, yy, c[1] + Math.sin(a) * d]} rotation={[t * 8 * rr(i, 9), t * 6, rr(i, 10) * 3]} scale={[s * 1.3, s * 0.35, s]} />;
  })}</>);
};

// ---------- grietas que se ramifican (calcomanía en el piso) ----------
const texGrietas = memo(() => cv(1024, 1024, (g) => {
  const cx = 512, cy = 512; let k = 1;
  const gr = g.createRadialGradient(cx, cy, 20, cx, cy, 300); gr.addColorStop(0, 'rgba(30,24,18,.55)'); gr.addColorStop(1, 'rgba(30,24,18,0)'); g.fillStyle = gr; g.fillRect(0, 0, 1024, 1024);
  g.strokeStyle = '#17120d'; g.lineCap = 'round'; g.lineJoin = 'round';
  const grieta = (x: number, y: number, a: number, L: number, w: number, d: number) => {
    let px = x, py = y; const pasos = Math.max(4, Math.floor(L / 14));
    g.lineWidth = w; g.beginPath(); g.moveTo(px, py);
    for (let s = 0; s < pasos; s++) { a += (rr(k++, 2) - 0.5) * 0.55; px += Math.cos(a) * L / pasos; py += Math.sin(a) * L / pasos; g.lineTo(px, py);
      if (d > 0 && rr(k++, 3) > 0.8) { g.stroke(); grieta(px, py, a + (rr(k++, 4) > 0.5 ? 1 : -1) * (0.5 + rr(k++, 5) * 0.5), L * 0.45, w * 0.6, d - 1); g.lineWidth = w; g.beginPath(); g.moveTo(px, py); }
      g.lineWidth = Math.max(1, w * (1 - s / pasos * 0.7)); }
    g.stroke();
  };
  for (let i = 0; i < 16; i++) { const a = i / 16 * Math.PI * 2 + rr(i, 1) * 0.3; grieta(cx + Math.cos(a) * 60, cy + Math.sin(a) * 90, a, 300 + rr(i, 6) * 160, 7, 2); }
}));
const matGrietas = memo(() => new THREE.MeshBasicMaterial({map: texGrietas(), transparent: true, depthWrite: false}));
export const GrietasDecal: React.FC<{p: [number, number, number]; s: number; op?: number; rot?: number}> = ({p, s, op = 1, rot = 0}) => {
  const m = matGrietas(); m.opacity = op;
  return <mesh position={[p[0], p[1] + 0.008, p[2]]} rotation={[-Math.PI / 2, 0, rot]} material={m} renderOrder={3}><planeGeometry args={[s, s]} /></mesh>;
};

// ---------- mazo de madera (cabeza de barril con dos aros claros y mango largo) ----------
const texMadera = memo(() => { const t = cv(256, 256, (g) => {
  g.fillStyle = '#a0662e'; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 70; i++) { g.strokeStyle = rr(i, 21) > 0.5 ? 'rgba(90,50,20,.45)' : 'rgba(200,140,80,.35)'; g.lineWidth = 1 + rr(i, 22) * 3; const x = rr(i, 23) * 256; g.beginPath(); g.moveTo(x, 0); g.bezierCurveTo(x + (rr(i, 24) - 0.5) * 30, 90, x + (rr(i, 25) - 0.5) * 30, 170, x + (rr(i, 26) - 0.5) * 20, 256); g.stroke(); }
}); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t; });
const matMadera = memo(() => new THREE.MeshLambertMaterial({map: texMadera()}));
const matMango = memo(() => new THREE.MeshLambertMaterial({color: '#7a4a22'}));
const AROS = new THREE.MeshLambertMaterial({color: '#e7e1d6'});
// el mango sale de la cabeza hacia +x; el pivote (mano) queda en el extremo del mango
export const Mazo: React.FC<{p: [number, number, number]; ang: number; L?: number; R?: number; s?: number; rotY?: number}> = ({p, ang, L = 4.4, R = 0.48, s = 1, rotY = 0}) => (
  <group position={p} rotation={[0, rotY, ang]} scale={s}>
    {/* el grupo gira alrededor del pivote; la cabeza está a -L sobre x */}
    <mesh material={matMango()} position={[-L / 2, 0, 0]} rotation={[0, 0, Math.PI / 2]}><cylinderGeometry args={[0.075, 0.085, L, 10]} /></mesh>
    <group position={[-L, 0, 0]}>
      <mesh material={matMadera()}><cylinderGeometry args={[R, R, R * 2.3, 22]} /></mesh>
      {[-1, 1].map(k => <mesh key={k} material={AROS} position={[0, k * R * 0.82, 0]}><cylinderGeometry args={[R * 1.03, R * 1.03, R * 0.22, 22]} /></mesh>)}
    </group>
  </group>
);

// ---------- estrellas de mareo (amarillas, giran alrededor de la cabeza) ----------
const ESTR = (() => { const s = new THREE.Shape(); for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2, r = i % 2 ? 0.42 : 1; const x = Math.sin(a) * r, y = Math.cos(a) * r; if (i) s.lineTo(x, y); else s.moveTo(x, y); } s.closePath(); return new THREE.ExtrudeGeometry(s, {depth: 0.18, bevelEnabled: true, bevelSize: 0.06, bevelThickness: 0.06, bevelSegments: 1}); })();
const AMAR = new THREE.MeshLambertMaterial({color: '#f6e86a', emissive: '#6e6420'});
export const EstrellasMareo: React.FC<{c: THREE.Vector3; r: number; f: number; n?: number; s?: number}> = ({c, r, f, n = 5, s = 0.07}) => (
  <>{Array.from({length: n}).map((_, i) => { const a = f * 0.16 + i / n * Math.PI * 2; return <mesh key={i} geometry={ESTR} material={AMAR} position={[c.x + Math.cos(a) * r, c.y + 0.03 * Math.sin(a * 2 + i), c.z + Math.sin(a) * r * 0.6]} rotation={[0, 0, f * 0.2 + i]} scale={s} />; })}</>
);
