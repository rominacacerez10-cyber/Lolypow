// Piezas básicas: texturas cargadas (TEX), materiales con mosaico, cajas, cilindros, piso y letreros.
// Las texturas de public/tex/ se cargan una vez en cargarModelo() (Beto3D.tsx) y quedan en TEX['nombre'].
import React, {useMemo} from 'react';
import * as THREE from 'three';
import {lambert, nearest, snap} from './ps1';

export const TEX: Record<string, THREE.Texture> = {};
const mcache = new Map<string, THREE.Material>();
// Material con la textura `name` repetida rx × ry veces (se guarda en caché). Si la textura no existe, gris.
export const tmat = (name: string, rx: number, ry: number, tint?: string): THREE.Material => {
  const k = `${name}|${Math.max(1, Math.round(rx * 4) / 4)}|${Math.max(1, Math.round(ry * 4) / 4)}|${tint ?? ''}`;
  let m = mcache.get(k);
  if (!m && !TEX[name]) { m = lambert('#999'); mcache.set(k, m); }
  if (!m) {
    const t = TEX[name].clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(Math.max(1, Math.round(rx * 4) / 4), Math.max(1, Math.round(ry * 4) / 4)); t.needsUpdate = true;
    m = snap(new THREE.MeshLambertMaterial({map: t, flatShading: true, ...(tint ? {color: tint} : {})})); mcache.set(k, m);
  }
  return m;
};
// Caja: color liso, o textura (t) en mosaico según su tamaño real (ts = metros por baldosa)
export const Caja: React.FC<{p?: [number, number, number]; s: [number, number, number]; c?: string | number; r?: [number, number, number]; t?: string; ts?: number; tint?: string}> = ({p = [0, 0, 0], s, c = '#888', r = [0, 0, 0], t, ts = 1.2, tint}) => {
  const m = useMemo(() => {
    if (!t) return lambert(c);
    const [x, y, z] = s;   // caras: +x,-x,+y,-y,+z,-z
    return [tmat(t, z / ts, y / ts, tint), tmat(t, z / ts, y / ts, tint), tmat(t, x / ts, z / ts, tint), tmat(t, x / ts, z / ts, tint), tmat(t, x / ts, y / ts, tint), tmat(t, x / ts, y / ts, tint)];
  }, [c, t, s[0], s[1], s[2], ts, tint]);
  return <mesh position={p} rotation={r} material={m as any}><boxGeometry args={s} /></mesh>;
};
export const Cil: React.FC<{p?: [number, number, number]; r: number; h: number; c: string | number; rot?: [number, number, number]; seg?: number}> = ({p = [0, 0, 0], r, h, c, rot = [0, 0, 0], seg = 8}) => {
  const m = useMemo(() => lambert(c), [c]);
  return <mesh position={p} rotation={rot} material={m}><cylinderGeometry args={[r, r, h, seg]} /></mesh>;
};

// Piso horizontal con textura en mosaico (w × d metros)
export const Piso: React.FC<{w: number; d: number; t?: string; ts?: number; y?: number; p?: [number, number, number]; tint?: string}> = ({w, d, t = 'piso_banco', ts = 1.6, y = 0, p, tint}) => {
  const m = useMemo(() => tmat(t, w / ts, d / ts, tint), [t, w, d, ts, tint]);
  return <mesh position={p ?? [0, y, 0]} rotation={[-Math.PI / 2, 0, 0]} material={m}><planeGeometry args={[w, d]} /></mesh>;
};

// Texto en una placa (canvas pequeño, píxeles duros)
export const Letrero: React.FC<{text: string; p: [number, number, number]; w: number; h: number; bg?: string; fg?: string; r?: [number, number, number]; size?: number}> = ({text, p, w, h, bg = '#1b5e20', fg = '#fff', r = [0, 0, 0], size = 18}) => {
  const m = useMemo(() => {
    const c = document.createElement('canvas'); c.width = 128; c.height = Math.max(16, Math.round(128 * h / w));
    const g = c.getContext('2d')!; g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); g.fillStyle = fg;
    g.font = `bold ${size}px monospace`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, c.width / 2, c.height / 2 + 1);
    return new THREE.MeshBasicMaterial({map: nearest(new THREE.CanvasTexture(c))});
  }, [text, bg, fg]);
  return <mesh position={p} rotation={r} material={m}><planeGeometry args={[w, h]} /></mesh>;
};
