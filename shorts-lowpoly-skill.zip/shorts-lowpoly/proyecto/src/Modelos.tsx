// Modelos 3D descargados (GLB / glTF). Se cargan una sola vez y cada <Obj> usa un clon.
// Para agregar uno:
//   1. Bájalo a public/modelos/ (los de Poly Haven con `python3 tools/polyhaven.py <id>` → public/modelos/ph/<id>/).
//   2. Ponle un nombre corto en MODELOS y, si no es public/modelos/<nombre>.glb, su ruta en RUTA.
//   3. Anota autor, enlace y licencia en CREDITOS.md (CC-BY obliga a dar crédito; nada NC).
import React from 'react';
import * as THREE from 'three';
import {GLTFLoader} from 'three/examples/jsm/loaders/GLTFLoader.js';
import {clone as skClone} from 'three/examples/jsm/utils/SkeletonUtils.js';
import {delayRender, continueRender, staticFile} from 'remotion';

export const MODELOS = ['gnomo', 'planta', 'silla', 'pastel', 'botellas', 'plato'] as const;
// ruta dentro de public/modelos/ (si no se pone, se busca <nombre>.glb)
const RUTA: Partial<Record<string, string>> = {
  gnomo: 'ph/garden_gnome/garden_gnome_1k.gltf',
  planta: 'ph/potted_plant_01/potted_plant_01_1k.gltf',
  silla: 'ph/painted_wooden_chair_02/painted_wooden_chair_02_1k.gltf',
  pastel: 'ph/carrot_cake/carrot_cake_1k.gltf',
  botellas: 'ph/wine_bottles_01/wine_bottles_01_1k.gltf',
  plato: 'ph/carved_wooden_plate/carved_wooden_plate_1k.gltf',
};
export type NombreModelo = typeof MODELOS[number];
const cache: Record<string, any> = {};
let promesa: Promise<void> | null = null;
export const cargarModelos = () => promesa ??= (async () => {
  await Promise.all(MODELOS.map(n => new Promise<void>((res, rej) => new GLTFLoader().load(staticFile(`modelos/${RUTA[n] ?? n + '.glb'}`), (g) => { cache[n] = g; res(); }, undefined, rej))));
})();
// Hook: devuelve true cuando ya cargaron todos (Remotion espera con delayRender)
export const useModelos = () => {
  const [ok, setOk] = React.useState(false);
  const [h] = React.useState(() => delayRender('modelos'));
  React.useEffect(() => { cargarModelos().then(() => { setOk(true); continueRender(h); }).catch((e) => { console.error('modelos', e); continueRender(h); }); }, []);
  return ok;
};
// caja del modelo en su espacio local
export const cajaDe = (n: NombreModelo) => new THREE.Box3().setFromObject(cache[n].scene);

// Objeto del modelo n: se escala a `alto` (m) o a `ancho` (m) y se apoya en y = 0, centrado en x/z.
//   tinte: multiplica el color · recolor: cambia el tono de la textura (conserva luces y sombras)
//   brillo: aclara · oculta: quita piezas por nombre de material
export const Obj: React.FC<{n: NombreModelo; alto?: number; ancho?: number; p?: [number, number, number]; rotY?: number; tinte?: string; recolor?: string; oculta?: string[]; brillo?: number}> = ({n, alto, ancho, p = [0, 0, 0], rotY = 0, tinte, recolor, oculta, brillo}) => {
  const {obj, k, off} = React.useMemo(() => {
    const o = skClone(cache[n].scene) as THREE.Object3D;
    if (oculta) { const fuera: THREE.Object3D[] = []; o.traverse((m: any) => { if (m.isMesh && (Array.isArray(m.material) ? m.material : [m.material]).some((x: any) => oculta.includes(x.name))) fuera.push(m); }); fuera.forEach(x => x.parent?.remove(x)); }
    const clip = (cache[n].animations ?? [])[0];   // si trae animación, se queda en su primer cuadro
    if (clip) { const mx = new THREE.AnimationMixer(o); mx.clipAction(clip).play(); mx.update(0); }
    o.updateMatrixWorld(true);
    const b = new THREE.Box3().setFromObject(o); const sz = b.getSize(new THREE.Vector3()); const c = b.getCenter(new THREE.Vector3());
    const k = alto ? alto / sz.y : ancho ? ancho / Math.max(sz.x, sz.z) : 1;
    o.traverse((m: any) => {
      if (!m.isMesh) return; m.frustumCulled = false;
      const mats = Array.isArray(m.material) ? m.material : [m.material];
      if (recolor) mats.forEach((x: any) => { if (x.map && !x.__rc) { const im = x.map.image; const c = document.createElement('canvas'); c.width = im.width; c.height = im.height; const g = c.getContext('2d')!; g.drawImage(im, 0, 0); g.globalCompositeOperation = 'color'; g.fillStyle = recolor; g.fillRect(0, 0, c.width, c.height); const t = new THREE.CanvasTexture(c); t.flipY = x.map.flipY; t.colorSpace = THREE.SRGBColorSpace; x.map = t; x.__rc = true; } });
      // materiales sin luz (MeshBasic): la textura se ve tal cual, como en los juegos de PS1
      m.material = mats.map((x: any) => { if (!x.map && !m.geometry.attributes.color) return new THREE.MeshLambertMaterial({color: tinte ? new THREE.Color(tinte) : (x.color ?? 0xbbbbbb), side: THREE.DoubleSide}); const y = new THREE.MeshBasicMaterial({map: x.map ?? null, color: tinte ? new THREE.Color(tinte) : (x.map ? 0xffffff : x.color ?? 0xcccccc), vertexColors: !!(m.geometry.attributes.color && !x.map), side: THREE.DoubleSide, transparent: x.transparent, opacity: x.opacity, alphaTest: x.alphaTest}); if (y.map) { y.map.anisotropy = 8; } if (brillo) y.color.multiplyScalar(brillo); return y; });
      if (m.material.length === 1) m.material = m.material[0];
    });
    return {obj: o, k, off: new THREE.Vector3(-c.x * k, -b.min.y * k, -c.z * k)};
  }, [n, alto, ancho, tinte, recolor, oculta?.join(','), brillo]);
  return <group position={p} rotation={[0, rotY, 0]}><group position={off.toArray()} scale={k}><primitive object={obj} /></group></group>;
};
