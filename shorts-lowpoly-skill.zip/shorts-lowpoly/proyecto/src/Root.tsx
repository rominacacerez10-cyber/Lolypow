// Composiciones del kit:
//   Ejemplo     el short de ejemplo completo (1080×1920, 30 fps)
//   EjemploSel  cuadros sueltos del ejemplo (lista SEL en Ejemplo.tsx) para revisar rápido sin renderizar todo
//   Poses       cuadrícula de movimientos y personas
import React from 'react';
import {Composition} from 'remotion';
import {Ejemplo, EjemploSel, SEL, TOTAL} from './Ejemplo';
import {Poses} from './Poses';

export const Root: React.FC = () => (
  <>
    <Composition id="Ejemplo" component={Ejemplo} durationInFrames={TOTAL} fps={30} width={1080} height={1920} />
    <Composition id="EjemploSel" component={EjemploSel} durationInFrames={SEL.length} fps={30} width={1080} height={1920} />
    <Composition id="Poses" component={Poses} durationInFrames={60} fps={30} width={1080} height={1920} />
  </>
);
