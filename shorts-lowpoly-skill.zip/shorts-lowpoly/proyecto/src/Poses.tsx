// POSES: cuadrícula para revisar movimientos y personas de un vistazo (y escoger cuadros que no se vean deformes).
// Cada fila es una lista de [clip, cuadro, giro en Y, persona?]. Sin persona = protagonista (personaje base con cara de foto).
// El cuadro de la composición se suma al cuadro de cada pose, así que en el Studio puedes recorrer el clip.
import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Beto3D, useRecursos} from './Beto3D';
import {Gl, Cam} from './Set';

export const POSES: [string, number, number, string?][][] = [
  [['saluda', 30, 0], ['camina', 20, 1.57], ['salta_feliz', 40, 0], ['celebra', 70, 0], ['sorpresa', 60, 0], ['susto', 40, 0]],
  [['tendido_espalda', 60, 1.57], ['tendido_cara', 60, 1.57], ['cae_brazos', 22, 0], ['agacha_brazos', 40, 0], ['cuatro2', 30, 1.57], ['sentado', 20, 0.8]],
  [['mira', 30, 0, 'Character_Male_35'], ['manos_cadera', 10, 0, 'Character_46_Female'], ['camina', 20, 0, 'Character_41_Female'], ['mira', 60, 0, 'Doctor'], ['mira', 60, 0, 'Piloto'], ['saluda', 30, 0, 'Rojo']],
  [['sentado', 20, 0.8, 'Character_37_Female'], ['sentado', 20, 0, 'Character_38_Female'], ['martillo', 30, 0, 'Character_Male_35'], ['carga', 40, 0, 'Character_Male_43'], ['agotado', 40, 0, 'Character_44_Female'], ['correr', 20, 1.57, 'Character_Male_40']],
];
const IDS = Array.from(new Set(POSES.flat().map(p => p[0])));

export const Poses: React.FC = () => {
  const {movs, mod} = useRecursos(IDS); const f0 = useCurrentFrame();
  if (!mod || !IDS.every(id => movs[id])) return null;
  return (<AbsoluteFill><Gl bg="#8fa8c0"><Cam pos={[0, 4.6, 26]} look={[0, 4.6, 0]} fov={34} />
    {POSES.flatMap((fila, j) => fila.map(([id, fr, ry, pe], i) => { const m = movs[id]; return <Beto3D key={j + '_' + i} modelo={mod} mov={m} f={Math.min(m.n - 1, fr + f0)} persona={pe} carita="neutral" rotY={ry} pos={[(i - 2.5) * 2.4, 9.5 - j * 3.2, 0]} />; }))}
  </Gl></AbsoluteFill>);
};
