# Créditos y licencias

Todo lo que trae este proyecto se puede usar en videos comerciales (monetizados). Lo único que **obliga a dar crédito** es el paquete de personas de Elbolillo (CC-BY 4.0): copia el crédito de abajo en la descripción del video o en los créditos finales.

## Modelos 3D

| Archivo | Qué es | Autor | Enlace | Licencia |
|---|---|---|---|---|
| `public/modelo/beto.glb`, `public/modelo/textura_original.png` | Personaje base «PSX Male Character» (919 vértices, esqueleto Rigify) | 32Dev3 | https://32dev3.itch.io/ | CC0 (dominio público) |
| `public/modelos/elbolillo/` | «Characters_ Extras»: 28 personas low poly con cara de foto | Elbolillo | https://sketchfab.com/3d-models/characters--extras-f2b0b976ecdd47b49254b512c7f152b3 | **CC-BY 4.0 (dar crédito)** |
| `public/modelos/ph/garden_gnome/` | Garden Gnome | Bhargav Kubal · Poly Haven | https://polyhaven.com/a/garden_gnome | CC0 |
| `public/modelos/ph/potted_plant_01/` | Potted Plant 01 | Poly Haven | https://polyhaven.com/a/potted_plant_01 | CC0 |
| `public/modelos/ph/painted_wooden_chair_02/` | Painted Wooden Chair 02 | Kirill Sannikov · Poly Haven | https://polyhaven.com/a/painted_wooden_chair_02 | CC0 |
| `public/modelos/ph/carrot_cake/` | Carrot Cake | Greg Zaal, James Ray Cock · Poly Haven | https://polyhaven.com/a/carrot_cake | CC0 |
| `public/modelos/ph/wine_bottles_01/` | Wine Bottles 01 | Rico Cilliers, Jurita Burger · Poly Haven | https://polyhaven.com/a/wine_bottles_01 | CC0 |
| `public/modelos/ph/carved_wooden_plate/` | Carved Wooden Plate | Jan Martens · Poly Haven | https://polyhaven.com/a/carved_wooden_plate | CC0 |

Crédito para pegar (obligatorio si usas a la gente del paquete):

> This work is based on "Characters_ Extras" (https://sketchfab.com/3d-models/characters--extras-f2b0b976ecdd47b49254b512c7f152b3) by Elbolillo (https://sketchfab.com/Elbolilloduro) licensed under CC-BY-4.0 (http://creativecommons.org/licenses/by/4.0/)

## Texturas e imágenes

| Archivo | Origen | Licencia |
|---|---|---|
| `public/tex/cielo_foto.png` | Recorte del HDRI «Kloofendal 48d Partly Cloudy (Pure Sky)» de Poly Haven — https://polyhaven.com/a/kloofendal_48d_partly_cloudy_puresky | CC0 |
| `public/caras/*.png` (10 caras: neutral, feliz, susto, llanto, cansado, serio, verde, doctor, piloto, mujer) | Generadas con IA para este kit (personas ficticias) | Libres de usar en tus videos |
| `public/tex/` resto (tapices, parquet, losa, duela, valla, pasto, asfalto, fachadas, agua, ladrillo, pista, cancha, toldo, cielo, cielo_nubes, madera, pared, vidrio, piso_banco, concreto) | Generadas con IA para este kit | Libres de usar en tus videos |
| `public/tex/concreto_gris.png`, `public/tex/concreto_suave.png` | Hechas con código (ruido procedural) | Libres de usar en tus videos |
| Utilería de `src/` (árboles, pasto, reloj, grietas, ciudad, faroles, etc.) | Dibujada en código (canvas / three.js) | Igual que el código |

## Movimientos

| Archivo | Origen | Licencia |
|---|---|---|
| `public/mov/*.json` (34 clips) | Generados con **Kimodo** de NVIDIA (modelo `Kimodo-SOMA-RP-v1`) a partir de las frases de `tools/prompts_movs.json`, y convertidos con `tools/exportar_mov.py` | El modelo está bajo la NVIDIA Open Model License: permite uso comercial y NVIDIA no reclama propiedad sobre lo que generas. El código de Kimodo es Apache-2.0. https://github.com/nv-tlabs/kimodo |

## Herramientas

- Remotion (https://www.remotion.dev): revisa su licencia; es gratis para personas y empresas pequeñas, las empresas grandes necesitan licencia de empresa.
- three.js y @react-three/fiber: MIT.
- ElevenLabs (voz, opcional): necesitas tu propia cuenta y llave; revisa los términos de tu plan para uso comercial.
- Efectos de sonido: no se incluyen. Usa efectos con licencia que te permita publicarlos.

## Si agregas cosas

Anota aquí autor, enlace y licencia de cada modelo o textura nueva. Sirven CC0 y CC-BY (dando crédito). **No uses nada NC (no comercial)** ni nada sin licencia clara.
