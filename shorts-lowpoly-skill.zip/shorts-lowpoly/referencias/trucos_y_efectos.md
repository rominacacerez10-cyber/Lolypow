# Trucos y efectos (todos en `src/Trucos.tsx` y `src/Utileria.tsx`)

## Orden de cualquier golpe
**Anticipación → acción → impacto → consecuencia.** Lo roto, el polvo, las grietas y los terrones salen DESPUÉS del impacto, nunca antes.

## Hoyo en el piso (stencil)
El canvas lleva `stencil: true` (en `Set.tsx`, componente `Gl`).
1. Celdas MÁSCARA del hoyo: `colorWrite: false`, `stencilFunc: Always`, `stencilZPass: Replace`, `renderOrder: -10`.
2. Piso con `stencilFunc: NotEqual` y `renderOrder: -5`: no se pinta donde está la máscara.
3. Pozo negro con `side: BackSide` abajo del piso.
El hoyo es de cuadritos irregulares y **se abre hasta que salta** (no antes).

## Techo que se rompe (`TechoRoto`)
Techo horizontal (rotado π/2 en X) a ~2.45 m; cámara abajo mirando hacia arriba; cielo detrás. Cuadrícula de cuadritos de ~7 cm que caen del centro hacia afuera en ~4 cuadros; los del borde quedan blancos (yeso) con su canto. El hueco, apenas del tamaño del personaje.

## Caída sobre una ciudad
Cámara que baja con aceleración: `y = 31 − 0.3·f − 0.0025·f²`, inclinada ~0.6 rad hacia abajo, fov ~80. Ciudad `CiudadReal` (InstancedMesh: manzanas de 15 m, calles de 5 m, banquetas, parques), neblina azulada. El personaje va pegado a la cámara (1.45 m delante, 0.2 abajo) agitando brazos y piernas.

## Golpe contra el piso
- Cae desde ~2.35 m: `y = 2.35·(1 − (f/F)²)`, pega en `F_PEGA`, rebote chico.
- La sombra crece mientras cae.
- Al pegar: temblor de cámara 7 cuadros (**solo posición**), grietas ramificadas (`GrietasDecal`) que crecen en ~5 cuadros, escombro blanco que sale volando y polvo.

## Enterrado por un mazo
`Mazo` de madera que gira desde arriba a la derecha y cae; DESPUÉS del golpe salen los `Terrones` (redondos) y el cuerpo baja.

## Mareado
Primer plano de la cara con la expresión «cansado» + `EstrellasMareo` girando cerca de la cabeza.

## Look PS1 (`src/ps1.tsx`)
Render a media resolución ampliado con píxeles duros, texturas chicas y un temblor leve de vértices (`strength` ≈ 0.28; más alto marea). Opción `px` en `Gl` para pixelear más un plano concreto.

## Detalles que hacen que se vea «caro»
- Reloj con números y manecillas; velocímetro con la aguja en la cifra exacta de la frase.
- Cielo de foto (HDRI de Poly Haven recortado) en lugar de color plano.
- Sombras de contacto bajo cada personaje y mueble.
- Polvo chico al despegar, polvo grande al aterrizar.
