# Movimiento

## Clips de Kimodo (`public/mov/*.json`)
El proyecto trae 34 clips listos (caminar, correr, saltar, sentadilla y salto, caer, tendido boca abajo, gatear, forcejear, saludar, susto, martillazo, subir escalera…). Para verlos todos: composición `Poses`. Para usar uno dentro de un plano (ver `src/Ejemplo.tsx`, cada plano recibe `{f, n, mov, mod}`):
`<Beto3D modelo={mod} mov={mov('cae_brazos')} f={f} carita="susto" pos={[0, 0, 0]} rotY={0.3} />`
Gente: la misma componente con `persona="Rojo"` (u otra del paquete).

### Hacer clips nuevos (si Kimodo está instalado)
- Agrega a `tools/prompts_movs.json`: `"id": ["prompt en inglés", segundos, semilla]`.
- Prompt concreto: quién + acción + velocidad + estilo. Ej.: «a person bear-crawls extremely fast on hands and feet», «a person falls forward and lands flat on the stomach», «a person struggles with the hips stuck, kicking the legs».
- `PYTHONPATH=~/Kimodo/repo HF_HUB_OFFLINE=1 python tools/generar_movs.py` (≈45 s por clip en CPU; el modelo de texto se carga una sola vez para todos).
- `python tools/exportar_mov.py <id>` → `public/mov/<id>.json`.
- Revisa el clip en `Poses` antes de usarlo: si los pies flotan o el gesto no se entiende, cambia el prompt o la semilla.

## Retargeting (cómo se mueve el esqueleto de Beto con un clip)
Por **dirección de hueso + giro**: para cada hueso se copia hacia dónde apunta en el clip y su torsión. Nombres de hueso **sin puntos** (three.js los quita): `DEF-spine` … `DEF-spine006` (cabeza), `DEF-upper_armL/R`, `DEF-forearmL/R`, `DEF-handL/R`, `DEF-thighL/R`, `DEF-shinL/R`, `DEF-footL/R`.

## Poses a mano
- `ajuste={(rig) => {...}}`: gira huesos DESPUÉS del clip. Úsalo para corregir lo que el clip no da (cabeza que mira a la cámara, brazo que sostiene algo).
- IK de brazo: `ikBrazo(rig, 'L', destino, polo, peso)`. IK genérico de 3 huesos: `ik2(rig, [b1, b2, b3], destino, polo, peso)` (destino y polo son `THREE.Vector3` en coordenadas del personaje).
- Atajos: `manosCabeza`, comer (IK de la mano a la boca), gatear (`tendido_cara` + `ik2` en brazos + espinillas dobladas).
- `extra(rig)`: cuelga objetos de un hueso (un mazo en la mano, un collarín, un casco).
- Para congelar una pose de un clip: `mov="agacha_brazos" f={24}` fijo.

## Reglas
- El gesto tiene que leerse en 1.5 s: si el espectador no entiende qué hace, exagera la pose.
- Pies en el piso (revisa la sombra). Nada de deslizarse.
- Gente del fondo también se mueve (comer, mirar, platicar), aunque sea poco.
