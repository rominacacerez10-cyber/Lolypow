# Revisión y render

## Revisar rápido (siempre antes del render completo)
1. En `src/Root.tsx`, la composición `…Sel` renderiza solo los cuadros de una lista (`SEL`, cuadros globales). Pon 1–2 cuadros por plano nuevo o corregido; en los golpes, uno antes y uno después del impacto.
2. `npx remotion render src/index.ts EjemploSel out/sel --sequence --image-format=jpeg --scale=0.5 --concurrency=3 --log=error`
3. Junta los JPG en una hoja (Python + Pillow, 3 por renglón) y **mírala tú** con la lista del final de `ERRORES_QUE_NO_SE_REPITEN.md`.
4. Corrige y repite. Solo cuando la hoja esté bien, render completo.

## Render completo
- Mudo y luego se le pone el audio: `npx remotion render src/index.ts <Composición> out/short_mudo.mp4 --muted --concurrency=3 --crf=19 --log=error`
- Si se cae, por tramos: `--frames=0-899` y `--frames=900-1769`, y se unen con `ffmpeg -f concat`.
- Audio: `python3 tools/mezcla_short.py` (voz + efectos ~13 dB abajo + música baja) → `out/audio.wav`.
- Unir: `ffmpeg -i out/short_mudo.mp4 -i out/audio.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 192k -shortest out/short_final.mp4`.
- Entrega 1080×1920, 30 fps. Para revisar en el celular, una copia de 540×960.

## Lado a lado con la referencia
`ffmpeg -i referencia.mp4 -i out/short_final.mp4 -filter_complex "[0:v]fps=30,scale=540:960[a];[1:v]scale=540:960[b];[a][b]hstack[v]" -map "[v]" -map 1:a -c:v libx264 -crf 21 -c:a aac lado_a_lado.mp4`

## Sonido
- Todo lo que aparece suena (pop, whoosh); todo lo que pega, golpea (impacto grave + escombro).
- Efectos de bibliotecas con licencia que permita publicar (las que tenga el usuario, o Freesound CC0/CC-BY con crédito). No uses la pista de otro creador.
- La voz siempre se entiende: efectos ~13 dB abajo, música más abajo todavía.

## Entrega
- Al usuario le das el MP4 final y, si hubo referencia, el lado a lado. Guarda solo la última versión para no llenar el disco.
- Créditos CC-BY en un texto listo para pegar en la descripción.
- **No subas nada a ninguna red**: eso lo hace el usuario.
