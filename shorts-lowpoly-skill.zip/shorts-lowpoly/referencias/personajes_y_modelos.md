# Personajes y modelos

## Protagonista (`src/Beto3D.tsx`)
- Cuerpo: personaje PSX con esqueleto Rigify (CC0, «psx-male-character» de 32Dev3 en itch.io), ~900 vértices, textura de 256×256.
- Cara: foto pegada en el rectángulo de la cara de la textura. Las 6 expresiones de Beto (neutral, feliz, susto, llanto, cansado, serio) están en `public/caras/` junto con caras de otros papeles (doctor, piloto, mujer, verde) y se cambian por plano (`carita="susto"`).
- **Cara del usuario**: pide una foto de frente, con luz pareja y fondo liso. Con el generador de imágenes saca las 6 expresiones de ESA persona (misma cara, mismo encuadre) y recórtalas igual que las de `public/caras/` (mismo tamaño y posición de ojos y boca). Revisa en un cuadro que no se vea borrosa ni corrida.
- Ropa: se recolorea la textura (camisa, pantalón) excluyendo la cara.

## Gente (paquete «Characters_ Extras» de Elbolillo, Sketchfab, CC-BY)
- 28 personajes con cara de foto (mujeres, hombres, dos sheriffs). Vienen sin esqueleto: `cargarPersonas` los riggea en código con el esqueleto del protagonista (ver errores 8–10).
- `persona="Rojo" | "Doctor" | "Piloto"` = versiones recoloreadas. Para un papel nuevo (mesero, policía), recolorea uno que no se deforme.
- Si un personaje se deforma al moverlo, cámbialo por otro; no lo pelees.
- Crédito obligatorio: «Characters_ Extras» por Elbolillo, CC-BY 4.0 (ya está en `CREDITOS.md`).

## De dónde bajar modelos
1. **Poly Haven** (CC0, sin cuenta, sin navegador): `python3 tools/polyhaven.py <id>` baja el glTF de 1k con sus texturas a `public/modelos/ph/<id>/`. Para ver qué hay: `https://api.polyhaven.com/assets?t=models`. También tiene HDRI (cielos de foto) y texturas.
2. **Sketchfab**: filtra por licencia **CC BY** o **CC0** y «Downloadable». Necesita la cuenta del usuario: que inicie sesión él en su navegador. Si el navegador bloquea la segunda descarga seguida, que la permita él; no cambies su configuración. Prefiere GLB.
3. **itch.io**: muchos paquetes PSX en CC0. Lee la licencia de cada uno.
- Descarta NC («NonCommercial»), «Editorial» y todo lo que no diga licencia.
- Anota cada modelo en `CREDITOS.md`: nombre, autor, enlace, licencia.
- Modelos de más de ~50 MB, fuera. Si un modelo carga roto, un intento más y luego se hace en código.

## Cargar y ajustar modelos (`src/Modelos.tsx`)
`<Obj src="modelos/ph/ArmChair_01/ArmChair_01_1k.gltf" pos={[x,y,z]} rot={[0,ry,0]} esc={1} />` con opciones:
- `recolor` / `tinte` / `brillo` / `gris` para cambiar color sin editar texturas;
- `sub={[...]}` para usar solo algunas sub-mallas (un edificio de un paquete con varios);
- `oculta={[...]}` para quitar partes (p. ej. una puerta con ventanas negras).

## Utilería en código que ya existe (`src/Utileria.tsx`, `src/Ciudad.tsx`)
Cielo de foto, pasto, árboles de canvas, sombras, reloj con números, velocímetro, cuadro con paisaje, terrones, pedazos, grietas ramificadas, mazo, estrellas de mareo, edificios con fachada de canvas, farol, ciudad vista desde arriba (InstancedMesh con manzanas, calles, banquetas y parques). Úsala antes de escribir algo nuevo.
