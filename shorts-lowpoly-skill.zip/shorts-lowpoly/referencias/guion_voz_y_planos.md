# Guion, voz y plan de planos

## Guion
- 35–60 s hablados (≈ 90–150 palabras). Tono de curiosidad: «¿Qué pasaría si…?», «Si saltaras como una pulga…».
- Frases cortas, una imagen por frase. Si una frase no se puede dibujar, se reescribe.
- **Cifras con fuente.** Cada dato (km/h, metros, precios, récords) va con su enlace en `guion_fuentes.md`. Si no hay fuente buena, se quita el dato.
- Cierre con remate visual (el golpe, la caída, la cara del personaje), no con texto.

## Voz
- ElevenLabs: una frase por archivo para poder ajustar cada una a su plano (`tools/voz_elevenlabs.py`). Si una frase queda más larga que su ventana, se acelera un poco con `atempo` (hasta 1.15) o se reescribe; nunca se corta a media palabra.
- Voz del usuario: que la grabe completa de corrido; se transcribe y se corta por frase.
- Tiempos por palabra con AssemblyAI o Whisper. Guarda un JSON `[{texto, ini, fin}]` por frase: de ahí salen los cortes de plano y los subtítulos.

## Subtítulos
Amarillos, chicos, con borde oscuro, en el tercio de abajo y **sin tapar la cara**. 2–5 palabras a la vez, sincronizados con la palabra.

## Plan de planos
Tabla que el usuario aprueba antes de construir:

| n.º | desde–hasta (s) | frase | qué se ve | cámara | movimiento del personaje |
|---|---|---|---|---|---|
| 1 | 0.0–1.4 | «Si saltaras como una pulga…» | Beto en la sala, se agacha | quieta, cuerpo completo | sentadilla → salto |

Reglas del plan:
- 1.2–1.8 s por plano; ~40–46 planos por minuto.
- Cada plano ilustra **literalmente** la frase (si dice «20 pisos», se ve una torre de 20 pisos; si dice «100 km/h», un velocímetro en 100).
- Alterna escalas: plano general → medio → primer plano de la cara en las reacciones.
- Cámara: ~40 % quieta, ~25 % deriva lenta, ~35 % movimiento suave (acercarse, seguir). Sin sacudidas salvo en golpes.
- Marca en la tabla los planos de golpe/caída: ahí va el orden anticipación → acción → impacto → consecuencia, y su efecto de sonido.

## Si hay un short de referencia
Mídelo antes de planear:
1. Pásalo a 30 fps y saca cuadros (`ffmpeg -i ref.mp4 -vf fps=30 cuadros/%04d.png`).
2. Cortes: `ffmpeg -i ref.mp4 -vf "select='gt(scene,0.3)',showinfo" -f null -` y corrígelos a ojo.
3. Por plano anota: duración, encuadre, tamaño del personaje en pantalla (fracción del alto), dónde está (u, v), qué hace la cámara.
4. Copia el **ritmo y el tipo de plano**, no su historia ni sus textos: el guion es del usuario.
