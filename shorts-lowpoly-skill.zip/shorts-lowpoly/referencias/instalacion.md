# Instalación

Regla: **primero revisa qué ya hay** (`node -v`, `python3 --version`, `ffmpeg -version`, espacio libre con `df -h ~`). Instala solo lo que falte y **pregunta antes** de cualquier instalación o descarga grande. Nunca pidas contraseñas ni llaves en el chat: las llaves van en variables de entorno que el usuario pone él.

## 1. Lo básico (obligatorio)
| Qué | Para qué | Cómo comprobar |
|---|---|---|
| Node 20+ | Remotion | `node -v` |
| ffmpeg | cortar, mezclar y unir audio | `ffmpeg -version` |
| Python 3.12 | herramientas (`tools/`) y Kimodo | `python3 --version` |
| Google Chrome | Remotion renderiza con Chrome | — |

En Mac sin ffmpeg: `brew install ffmpeg` (si no hay Homebrew, pregúntale antes de instalarlo).

Después, en `proyecto/`:
```bash
npm install
npm run modelos      # baja de Poly Haven (CC0) los 6 modelos de utilería del ejemplo, ~19 MB, con curl
npx remotion render src/index.ts Ejemplo out/ejemplo.mp4 --scale=0.5 --concurrency=3
```
`npm run modelos` va aparte para que el ZIP pese menos; deja los modelos en `public/modelos/ph/`. Abre `out/ejemplo.mp4` y enséñaselo al usuario. Si sale, lo básico está listo.

## 2. Voz y tiempos (cuentas del usuario)
- **ElevenLabs** (voz de IA): el usuario crea su llave en elevenlabs.io y la pone en su terminal: `export ELEVENLABS_API_KEY=...` (o en un `.env` que NO se comparte). `tools/voz_elevenlabs.py` la lee de ahí.
- **AssemblyAI** (tiempos por palabra): igual, `ASSEMBLYAI_API_KEY`. Alternativa sin cuenta: Whisper local.
- Si el usuario prefiere su voz: que grabe la narración completa de corrido, y se transcribe igual.

## 3. Generador de imágenes (caras y texturas)
Para las 6 expresiones de la cara y texturas planas (cielo, tapiz, concreto). Sirve ChatGPT/Codex con la sesión del usuario, o el generador que ya use. Con Codex CLI: `codex exec` con un brief que pida **«6 imágenes de la MISMA persona: neutral, feliz, susto, llanto, cansado, serio — FOTOGRAFÍA REAL, de frente, fondo liso»**.

## 4. Kimodo (opcional, movimientos humanos con texto) — ~20 GB
Kimodo es de NVIDIA (código Apache-2.0; el modelo `Kimodo-SOMA-RP-v1` va con la NVIDIA Open Model License, que permite uso comercial). El proyecto ya trae **34 movimientos hechos** en `public/mov/`; instala Kimodo solo si el usuario quiere movimientos nuevos. **Pregunta antes: pesa ~20 GB** (modelo de texto Llama 3 8B ≈ 15 GB, Kimodo ≈ 2.1 GB, codificador LLM2Vec ≈ 0.3 GB).

Pasos que funcionaron en una Mac con Apple Silicon (solo CPU, ~45 s por movimiento de 3–4 s):
1. `git clone https://github.com/nv-tlabs/kimodo.git` en una carpeta propia (p. ej. `~/Kimodo/repo`) y un venv con Python 3.12: `python3.12 -m venv ~/Kimodo/.venv`.
2. `pip install torch torchvision` y luego las dependencias del repo. **La extensión C++ `MotionCorrection` NO compila en Apple Silicon** (usa banderas de Intel como `-msse4.1`): por eso `pip install -e .` falla. No pasa nada: instala las dependencias que pide `pyproject.toml` y corre Kimodo con `PYTHONPATH=~/Kimodo/repo` (sin instalar el paquete). Sin esa extensión, Kimodo funciona igual (solo no hace la corrección de pies de ese módulo).
3. **Modelo de texto Llama 3 8B Instruct**: es «gated». El usuario entra a huggingface.co/meta-llama/Meta-Llama-3-8B-Instruct con SU cuenta, acepta la licencia de Meta (suelen aprobar en minutos) y en la terminal hace `hf auth login` con su token. **No uses espejos de terceros para saltarte la aceptación de la licencia.**
4. Si la descarga va lenta (2–3 MB/s), descarga los 4 archivos `.safetensors` en paralelo por rangos (un script con hilos y `Range: bytes=…`) y luego déjalos en la caché de Hugging Face con el nombre que espera Kimodo.
5. Si Python dice que no hay certificados (Python de python.org en Mac), corre «Install Certificates.command» o usa `certifi` dentro del venv.
6. Prueba con `tools/generar_movs.py` (lee `tools/prompts_movs.json`). Es normal ver «Text encoder service is unreachable, falling back to local LLM2Vec encoder». Con todo descargado puedes correr con `HF_HUB_OFFLINE=1`.
7. Convierte cada `.npz` a JSON para three.js con `tools/exportar_mov.py` → `public/mov/<id>.json` (rotaciones por hueso, 30 fps).

## 5. Si algo falla
- Render negro o un video que no aparece: mira el punto 32 de `ERRORES_QUE_NO_SE_REPITEN.md`.
- `npx remotion` se queda sin memoria o se cae: baja `--concurrency` a 2 y renderiza por tramos (`--frames=0-899`, `--frames=900-1769`) y únelos con ffmpeg.
- Un modelo GLB no carga: revisa la consola de `npx remotion studio`.
