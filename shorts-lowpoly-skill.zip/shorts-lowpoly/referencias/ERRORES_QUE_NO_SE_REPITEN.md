# Errores que ya cometió Claude haciendo estos shorts (y cómo se arreglaron)

Cada error salió de una corrida real: 3 shorts la primera noche y luego 11 rondas de correcciones hasta que el creador dijo «ya está bien hecho». Léelos todos antes de empezar. Al final hay una **lista para revisar cada cuadro**.

## A. Lo que hizo que el primer intento «no se pareciera en nada»

1. **Personajes, carros y animales hechos de cajas.** Se veía de juguete y barato.
   → Personajes 3D reales (con malla, textura y cara de foto) y modelos descargados. Lo que se haga en código tiene que estar muy trabajado: formas redondeadas, texturas, sombras, detalles.
2. **Cámara que temblaba todo el tiempo**, con sacudidas, destellos y líneas de velocidad en cada plano. Mareaba y no se veía al personaje.
   → Medido en un short bueno a 30 fps: cámara **quieta el 38 % del tiempo**, deriva lenta el 25 % y movimiento suave el 37 %. **Sin sacudidas ni destellos**. El temblor solo dura unos 7 cuadros en un impacto. Las líneas de velocidad, en 1 o 2 planos como mucho.
3. **Planos largos con poco que ver.** El bueno tiene **46 planos en 59 s** (mediana de 1.4 s); el primer intento tenía 6–8 escenas de 6 s.
   → Un plano por frase o media frase. Cada plano ilustra **literalmente** lo que dice la voz.
4. **Personaje chico y lejos**, perdido en el escenario.
   → El personaje ocupa buena parte del cuadro y se le ve la cara. Si el creador dice «acércalo», acércalo **más y más abajo** de lo que crees.
5. **El «temblor» de los vértices del estilo PS1 muy fuerte.** Parecía que todo vibraba.
   → En `ps1.tsx`, intensidad baja (`strength` ≈ 0.28). El look PS1 es pixel duro y texturas chicas, no gelatina.

## B. Personajes

6. **Cara de caja o cara dibujada.** El estilo pide cuerpo low poly con **cara de foto real**.
   → Cara de foto pegada en el rectángulo de la textura. 6 expresiones de la MISMA persona (neutral, feliz, susto, llanto, cansado, serio) hechas con un generador de imágenes. Textura de cara de buena resolución: con 72×116 píxeles se veía borrosa.
7. **Brazos que no subían.** El clip de movimiento sí los subía, pero el render se quedaba con los brazos abajo: el retargeting estaba mal.
   → Retargeting por **dirección de hueso + giro**. Ojo: three.js **quita los puntos** de los nombres de hueso (`DEF-upper_arm.L` → `DEF-upper_armL`). Si un hueso no se mueve, revisa primero el nombre.
8. **Gente sin esqueleto.** El paquete de personajes venía como malla estática.
   → Se riggea en código con el esqueleto del protagonista: peso por cercanía a los segmentos de hueso, **brazos de la malla girados hacia abajo antes de calcular pesos** (para que coincida la pose de reposo).
9. **Pantalones que salían «como alas»** al mover las piernas.
   → Limitar los pesos por familia de malla: las islas de piernas solo toman huesos de piernas y cadera.
10. **Personajes que se deforman** (mangas o brazos estirados en ciertos modelos).
    → No se pelea con ese modelo: se cambia por otro del paquete y se recolorea (`persona="Piloto"`, `"Doctor"`, `"Rojo"`). Al recolorear se excluyen los rectángulos UV de la cara.
11. **Gente quieta como maniquí** en una cena o una calle.
    → Cada persona hace algo: come (IK de la mano a la boca), mira, se lleva las manos a la cabeza, platica.

## C. Escenarios y modelos

12. **Ambientes vacíos.** → Cuadros, reloj **con números**, plantas, gnomo, pastel, botellas, sillas, platos, cielo de foto, árboles. La utilería de Poly Haven (CC0) se baja sin navegador con su API.
13. **«Pon una silla»**: hacer un sillón en código cuando existe uno real.
    → Si es un objeto común, **búscalo y bájalo** (Poly Haven, Sketchfab CC0/CC-BY). Código solo para lo que no existe o sale roto.
14. **Modelos que bajan rotos** (un jet con pedazos negros, un marco negro, un martillo equivocado).
    → Si después de un intento sigue roto, se hace en código y ya.
15. **Modelos gigantes** (un árbol de 214 MB).
    → Fuera todo lo de más de ~50 MB. Los árboles van en código (`ArbolBB`, de canvas).
16. **Bajar un modelo con licencia NC** («no comercial»). → Se descarta aunque sea perfecto. Solo CC0 o CC-BY, con crédito.
17. **El navegador frenó la segunda descarga seguida.** → No toques permisos del navegador del usuario. Pídele que permita las descargas él, o usa una API (Poly Haven) que no pasa por el navegador.
18. **Techo que parecía pared.** La cámara estaba de frente a una superficie vertical gris.
    → Un techo es **horizontal**, arriba, con la cámara abajo mirando hacia arriba y el cielo detrás del hueco.
19. **Piso o techo que se rompía de forma simétrica o cuadrada**, o un hueco enorme.
    → Hueco irregular de cuadritos (~7 cm), apenas del tamaño del personaje, que se abre del centro hacia afuera en ~4 cuadros, con canto en cada borde roto.
20. **Ciudad «congelada»** vista desde arriba en una caída.
    → La cámara **cae** con aceleración, inclinada; calles y manzanas bien definidas (manzanas de ~15 m, calles de ~5 m, banquetas, parques), neblina azulada a lo lejos, el personaje pegado a la cámara agitando brazos y piernas.

## D. Acciones y movimiento

21. **Romper antes de tiempo**: el piso ya tenía hoyo antes del salto; las grietas salían antes de que pegara.
    → Orden fijo: **anticipación → acción → impacto → consecuencia**. El piso aguanta hasta que salta. Las grietas, el polvo y los terrones salen DESPUÉS del golpe.
22. **Personaje «acostado»** en vez de caer, o tirado sin que se vea el golpe.
    → Se ve caer desde ~2.3 m (`y = 2.35·(1 − (f/F)²)`), la **sombra crece antes**, pega, rebota poquito, tiembla la cámara 7 cuadros y crecen las grietas en ~5 cuadros.
23. **Gatear acostado boca arriba.** → Gatear = boca abajo, rodillas dobladas, brazos que avanzan (clip `tendido_cara` + IK de brazos + espinillas dobladas). En Kimodo, el prompt que mejor salió fue «bear-crawls extremely fast».
24. **Atorado en un hueco sin moverse.** → Forcejea: la cadera fija en el borde, tiembla y patalea.
25. **Temblor de cámara que gira la imagen** en una toma cenital.
    → El temblor mueve **solo la posición** de la cámara, nunca un punto del `lookAt`.
26. **Movimientos que no se ven naturales** (brazos rígidos, pies que flotan).
    → Clip de Kimodo con prompt concreto en inglés (acción + velocidad + estilo), y luego `ajuste` a mano en los huesos que hagan falta. Revisa los pies contra el piso en el cuadro.

## E. Proceso

27. **Rehacer encima de lo aprobado** y romper planos que ya estaban bien.
    → Cada ronda va en un archivo nuevo que sobrescribe solo los planos que cambian (`Planos2.tsx`, `Planos3.tsx`…).
28. **Entregar sin mirar.** Un render negro o una cara deformada llegó al usuario.
    → Siempre: cuadros sueltos → hoja → mirarla → corregir → render completo.
29. **Resolver solo parte de las correcciones.** → Lista con cada punto del usuario; se entregan todos en la misma ronda.
30. **Inventar cifras** en el guion o en lo que dice el chat. → Solo datos con fuente; lo que no se pudo verificar se reescribe.
31. **Bucles de renders en zsh** con `set -- $c` que no separaban palabras. → Bucles en Python.
32. **El editor de video congeló un video en el cuadro equivocado** (Remotion `<Freeze frame={0}>` dentro de un `Sequence` que no empieza en 0 → video negro).
    → Envolver en `<Sequence from={0} layout="none">` antes del `Freeze`.

## Lista para revisar CADA cuadro de la hoja
- [ ] ¿Hay algo hecho de cajas o demasiado simple?
- [ ] ¿El personaje se ve grande, con la cara visible y sin deformarse?
- [ ] ¿La cámara está quieta o con deriva lenta (sin sacudida fuera de un golpe)?
- [ ] ¿El plano ilustra literalmente la frase que suena?
- [ ] ¿La acción se lee (anticipación → acción → impacto → consecuencia)?
- [ ] ¿Nada roto antes de tiempo? ¿Lo roto es irregular?
- [ ] ¿El ambiente tiene vida (gente haciendo algo, objetos, cielo)?
- [ ] ¿Algo negro, vacío, cortado o fuera de cuadro?
- [ ] ¿Subtítulo legible y sin tapar la cara?
